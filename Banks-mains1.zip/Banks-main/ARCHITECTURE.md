# Bank plugin working split

## BankingCore
Server Bank, player balances, loans, shared debt rules, grace, bad debt, enforcement and negative balance.

## PrivateBankCore
Private bank ownership, capital, deposits, private loans, review + reputation, bankruptcy and transfer of obligations.

## Shared API
The two cores communicate through `org.kalistudio.kBank.api` interfaces and Bukkit events. Avoid direct access to the other core's internal classes.

Large manager/core files remain as placeholders for the two developers to implement from the original source.
