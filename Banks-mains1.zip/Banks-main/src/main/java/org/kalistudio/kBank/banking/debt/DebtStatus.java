package org.kalistudio.kBank.banking.debt;
public enum DebtStatus { CURRENT, GRACE, BAD_DEBT, ENFORCED, PAID }
