package org.kalistudio.kBank.banking.loan;
import java.math.BigDecimal;
public final class LoanPolicy {
    private LoanPolicy() {}
    public static final long MIN_LOAN = 20_000L;
    public static final long MAX_LOAN = 2_000_000L;
    public static final long MIN_PLAYER_BALANCE = 500L;
    public static final BigDecimal INTEREST_PERCENT = new BigDecimal("5.0");
    public static final int INITIAL_GRACE_DAYS = 3;
}
