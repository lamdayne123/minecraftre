package org.kalistudio.kBank.service;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import org.kalistudio.kBank.KBank;

import java.util.UUID;

public class DailyInterestService {

    private final KBank plugin;
    private final InterestService interestService;

    private BukkitTask task;

    public DailyInterestService(KBank plugin, InterestService interestService) {
        this.plugin = plugin;
        this.interestService = interestService;
    }

    /**
     * Bắt đầu hệ thống kiểm tra lãi.
     *
     * Chạy mỗi 1 giờ để kiểm tra player online.
     * InterestService sẽ tự xác định đã qua bao nhiêu ngày
     * kể từ lần tính lãi cuối cùng.
     */
    public void start() {

        if (task != null) {
            task.cancel();
        }

        long interval = 20L * 60L * 60L;

        task = Bukkit.getScheduler().runTaskTimer(
                plugin,
                this::processOnlinePlayers,
                20L,
                interval
        );

        plugin.getLogger().info(
                "Daily interest service đã được khởi động."
        );
    }

    /**
     * Xử lý tất cả player đang online.
     */
    private void processOnlinePlayers() {

        for (Player player : Bukkit.getOnlinePlayers()) {

            UUID uuid = player.getUniqueId();

            double interest = interestService.applyInterest(uuid);

            if (interest <= 0) {
                continue;
            }

            String message = plugin.getConfig()
                    .getString(
                            "messages.deposit.interest",
                            "&aBạn nhận được &e%amount% &atiền lãi."
                    );

            message = message.replace(
                    "%amount%",
                    String.format("%.2f", interest)
            );

            player.sendMessage(
                    message.replace("&", "§")
            );
        }
    }

    /**
     * Dừng scheduler.
     */
    public void stop() {

        if (task != null) {
            task.cancel();
            task = null;
        }

        plugin.getLogger().info(
                "Daily interest service đã được dừng."
        );
    }

    /**
     * Kiểm tra scheduler có đang chạy không.
     */
    public boolean isRunning() {
        return task != null;
    }
}