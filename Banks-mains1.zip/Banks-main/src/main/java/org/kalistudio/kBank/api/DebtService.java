package org.kalistudio.kBank.api;
import java.math.BigDecimal;
import java.util.UUID;
import org.kalistudio.kBank.api.model.DebtSnapshot;
public interface DebtService {
    DebtSnapshot getDebt(UUID player);
    DebtSnapshot createDebt(UUID player, BigDecimal amount);
    boolean repay(UUID player, BigDecimal amount);
}
