package org.kalistudio.kBank.privatebank;
import java.math.BigDecimal;
public final class PrivateBankPolicy {
    private PrivateBankPolicy() {}
    public static final long MINIMUM_CAPITAL = 1_000_000L;
    public static final int MAX_BANKS_PER_OWNER = 2;
    public static final BigDecimal MIN_DEPOSIT_INTEREST_PERCENT = new BigDecimal("0.2");
    public static final BigDecimal MAX_DEPOSIT_INTEREST_PERCENT = new BigDecimal("2.0");
    public static final BigDecimal MIN_LOAN_INTEREST_PERCENT = new BigDecimal("3.0");
    public static final BigDecimal MAX_LOAN_INTEREST_PERCENT = new BigDecimal("10.0");
    public static final BigDecimal BANKRUPTCY_REPUTATION_THRESHOLD = new BigDecimal("1.0");
    public static final BigDecimal DEPOSITOR_COMPENSATION_PERCENT = new BigDecimal("2.0");
}
