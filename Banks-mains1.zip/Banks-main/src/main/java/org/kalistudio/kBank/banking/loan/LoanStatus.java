package org.kalistudio.kBank.banking.loan;
public enum LoanStatus { ACTIVE, GRACE, BAD_DEBT, COMPLETED, TRANSFERRED }
