package org.kalistudio.kBank.api.event;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.kalistudio.kBank.api.model.PrivateBankSnapshot;

public final class PrivateBankBankruptEvent extends Event {
    private static final HandlerList HANDLERS = new HandlerList();
    private final PrivateBankSnapshot snapshot;
    public PrivateBankBankruptEvent(PrivateBankSnapshot snapshot) { this.snapshot = snapshot; }
    public PrivateBankSnapshot getSnapshot() { return snapshot; }
    @Override public HandlerList getHandlers() { return HANDLERS; }
    public static HandlerList getHandlerList() { return HANDLERS; }
}
