package org.kalistudio.kBank.api.model;
import java.math.BigDecimal;
import java.util.UUID;
import org.kalistudio.kBank.banking.loan.LoanStatus;
public record LoanSnapshot(UUID borrower, String bankId, BigDecimal principal, BigDecimal remainingDebt, LoanStatus status, int graceUses, long createdAt, long dueAt) {}
