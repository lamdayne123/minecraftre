package org.kalistudio.kBank.privatebank;
public enum PrivateBankStatus { ACTIVE, WARNING, BANKRUPT }
