package org.kalistudio.kBank.api.model;
import java.math.BigDecimal;
import java.util.UUID;
import org.kalistudio.kBank.privatebank.PrivateBankStatus;
public record PrivateBankSnapshot(String bankId, String name, UUID owner, BigDecimal capital, BigDecimal reputation, double stars, PrivateBankStatus status) {}
