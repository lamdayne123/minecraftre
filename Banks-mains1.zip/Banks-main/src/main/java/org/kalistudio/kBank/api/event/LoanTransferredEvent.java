package org.kalistudio.kBank.api.event;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.kalistudio.kBank.api.model.LoanSnapshot;

public final class LoanTransferredEvent extends Event {
    private static final HandlerList HANDLERS = new HandlerList();
    private final LoanSnapshot snapshot;
    public LoanTransferredEvent(LoanSnapshot snapshot) { this.snapshot = snapshot; }
    public LoanSnapshot getSnapshot() { return snapshot; }
    @Override public HandlerList getHandlers() { return HANDLERS; }
    public static HandlerList getHandlerList() { return HANDLERS; }
}
