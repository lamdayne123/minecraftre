package org.kalistudio.kBank.api.model;
import java.math.BigDecimal;
import java.util.UUID;
import org.kalistudio.kBank.banking.debt.DebtStatus;
import org.kalistudio.kBank.banking.debt.DebtType;
public record DebtSnapshot(UUID debtor, BigDecimal remainingDebt, DebtStatus status, DebtType type, int graceUses, long createdAt, long badDebtSince) {}
