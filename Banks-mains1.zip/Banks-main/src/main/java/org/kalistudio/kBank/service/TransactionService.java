package org.kalistudio.kBank.banking.transaction;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.entity.Player;
import org.kalistudio.kBank.KBank;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.*;
import java.util.UUID;

public final class TransactionService {

    private static final int SCALE = 2;

    private final KBank plugin;
    private final Economy economy;

    public TransactionService(KBank plugin) {
        if (plugin == null) {
            throw new IllegalArgumentException("plugin cannot be null");
        }

        if (plugin.getEconomy() == null) {
            throw new IllegalStateException(
                    "Vault Economy is not available"
            );
        }

        this.plugin = plugin;
        this.economy = plugin.getEconomy();

        createTransactionTable();
    }

    // =========================================================
    // PLAYER -> BANK
    // =========================================================

    public synchronized TransactionResult depositToBank(
            Player player,
            UUID bankId,
            BigDecimal amount
    ) {

        if (player == null || bankId == null) {
            return fail("INVALID_ARGUMENT");
        }

        amount = money(amount);

        if (!positive(amount)) {
            return fail("INVALID_AMOUNT");
        }

        if (!hasBalance(player, amount)) {
            return fail("INSUFFICIENT_FUNDS");
        }

        EconomyResponse withdraw =
                economy.withdrawPlayer(
                        player,
                        amount.doubleValue()
                );

        if (!withdraw.transactionSuccess()) {
            return fail("ECONOMY_WITHDRAW_FAILED");
        }

        try {

            addBankBalance(bankId, amount);

            long transactionId =
                    record(
                            player.getUniqueId(),
                            bankId,
                            "DEPOSIT",
                            amount,
                            "PLAYER_TO_BANK"
                    );

            return success(
                    transactionId,
                    amount
            );

        } catch (Exception e) {

            // Không để tiền biến mất nếu database lỗi.
            economy.depositPlayer(
                    player,
                    amount.doubleValue()
            );

            plugin.getLogger().severe(
                    "[TransactionService] Deposit failed: "
                            + e.getMessage()
            );

            return fail("DATABASE_ERROR");
        }
    }

    // =========================================================
    // BANK -> PLAYER
    // =========================================================

    public synchronized TransactionResult withdrawFromBank(
            Player player,
            UUID bankId,
            BigDecimal amount
    ) {

        if (player == null || bankId == null) {
            return fail("INVALID_ARGUMENT");
        }

        amount = money(amount);

        if (!positive(amount)) {
            return fail("INVALID_AMOUNT");
        }

        try {

            removeBankBalance(
                    bankId,
                    amount
            );

            EconomyResponse deposit =
                    economy.depositPlayer(
                            player,
                            amount.doubleValue()
                    );

            if (!deposit.transactionSuccess()) {

                addBankBalance(
                        bankId,
                        amount
                );

                return fail(
                        "ECONOMY_DEPOSIT_FAILED"
                );
            }

            long transactionId =
                    record(
                            bankId,
                            player.getUniqueId(),
                            "WITHDRAW",
                            amount,
                            "BANK_TO_PLAYER"
                    );

            return success(
                    transactionId,
                    amount
            );

        } catch (InsufficientBankFundsException e) {

            return fail(
                    "INSUFFICIENT_BANK_FUNDS"
            );

        } catch (Exception e) {

            plugin.getLogger().severe(
                    "[TransactionService] Withdraw failed: "
                            + e.getMessage()
            );

            return fail("DATABASE_ERROR");
        }
    }

    // =========================================================
    // PLAYER -> PLAYER
    // =========================================================

    public synchronized TransactionResult transfer(
            Player sender,
            Player receiver,
            BigDecimal amount
    ) {

        if (sender == null || receiver == null) {
            return fail("INVALID_ARGUMENT");
        }

        if (sender.getUniqueId().equals(
                receiver.getUniqueId()
        )) {
            return fail("SELF_TRANSFER");
        }

        amount = money(amount);

        if (!positive(amount)) {
            return fail("INVALID_AMOUNT");
        }

        if (!hasBalance(sender, amount)) {
            return fail("INSUFFICIENT_FUNDS");
        }

        EconomyResponse withdraw =
                economy.withdrawPlayer(
                        sender,
                        amount.doubleValue()
                );

        if (!withdraw.transactionSuccess()) {
            return fail(
                    "ECONOMY_WITHDRAW_FAILED"
            );
        }

        EconomyResponse deposit =
                economy.depositPlayer(
                        receiver,
                        amount.doubleValue()
                );

        if (!deposit.transactionSuccess()) {

            economy.depositPlayer(
                    sender,
                    amount.doubleValue()
            );

            return fail(
                    "ECONOMY_DEPOSIT_FAILED"
            );
        }

        try {

            long transactionId =
                    record(
                            sender.getUniqueId(),
                            receiver.getUniqueId(),
                            "TRANSFER",
                            amount,
                            "PLAYER_TO_PLAYER"
                    );

            return success(
                    transactionId,
                    amount
            );

        } catch (SQLException e) {

            /*
             * Tiền đã chuyển thành công.
             * Không rollback mù vì Vault có thể tiếp tục lỗi.
             */
            plugin.getLogger().severe(
                    "[TransactionService] Transfer completed "
                            + "but transaction logging failed: "
                            + e.getMessage()
            );

            return fail(
                    "TRANSACTION_LOG_FAILED"
            );
        }
    }

    // =========================================================
    // LOAN DISBURSEMENT
    // =========================================================

    /**
     * Chỉ chuyển tiền.
     *
     * LoanService/DebtCore chịu trách nhiệm tạo khoản vay/nợ.
     */
    public synchronized TransactionResult disburseLoan(
            Player player,
            BigDecimal amount,
            String bankId
    ) {

        if (player == null) {
            return fail("INVALID_ARGUMENT");
        }

        amount = money(amount);

        if (!positive(amount)) {
            return fail("INVALID_AMOUNT");
        }

        EconomyResponse deposit =
                economy.depositPlayer(
                        player,
                        amount.doubleValue()
                );

        if (!deposit.transactionSuccess()) {
            return fail(
                    "ECONOMY_DEPOSIT_FAILED"
            );
        }

        try {

            long transactionId =
                    record(
                            null,
                            player.getUniqueId(),
                            "LOAN_DISBURSEMENT",
                            amount,
                            "BANK_TO_PLAYER:"
                                    + safe(bankId)
                    );

            return success(
                    transactionId,
                    amount
            );

        } catch (SQLException e) {

            economy.withdrawPlayer(
                    player,
                    amount.doubleValue()
            );

            return fail(
                    "TRANSACTION_LOG_FAILED"
            );
        }
    }

    // =========================================================
    // DEBT REPAYMENT
    // =========================================================

    /**
     * DebtCore quyết định số tiền phải trả.
     * TransactionService chỉ thực hiện movement.
     */
    public synchronized TransactionResult collectRepayment(
            Player player,
            BigDecimal amount,
            String bankId
    ) {

        if (player == null) {
            return fail("INVALID_ARGUMENT");
        }

        amount = money(amount);

        if (!positive(amount)) {
            return fail("INVALID_AMOUNT");
        }

        if (!hasBalance(player, amount)) {
            return fail(
                    "INSUFFICIENT_FUNDS"
            );
        }

        EconomyResponse withdraw =
                economy.withdrawPlayer(
                        player,
                        amount.doubleValue()
                );

        if (!withdraw.transactionSuccess()) {
            return fail(
                    "ECONOMY_WITHDRAW_FAILED"
            );
        }

        try {

            long transactionId =
                    record(
                            player.getUniqueId(),
                            null,
                            "DEBT_REPAYMENT",
                            amount,
                            "PLAYER_TO_BANK:"
                                    + safe(bankId)
                    );

            return success(
                    transactionId,
                    amount
            );

        } catch (SQLException e) {

            economy.depositPlayer(
                    player,
                    amount.doubleValue()
            );

            return fail(
                    "TRANSACTION_LOG_FAILED"
            );
        }
    }

    // =========================================================
    // ENFORCEMENT
    // =========================================================

    /**
     * Thu phần tiền player hiện có.
     *
     * DebtCore quyết định 20%.
     * Phần thiếu sẽ do NegativeBalanceManager/DebtCore xử lý.
     */
    public synchronized TransactionResult collectEnforcement(
            Player player,
            BigDecimal requestedAmount,
            String bankId
    ) {

        if (player == null) {
            return fail("INVALID_ARGUMENT");
        }

        requestedAmount =
                money(requestedAmount);

        if (!positive(requestedAmount)) {
            return fail("INVALID_AMOUNT");
        }

        BigDecimal balance =
                money(
                        economy.getBalance(player)
                );

        BigDecimal collected =
                balance.min(requestedAmount);

        if (!positive(collected)) {
            return success(
                    0,
                    BigDecimal.ZERO
            );
        }

        EconomyResponse withdraw =
                economy.withdrawPlayer(
                        player,
                        collected.doubleValue()
                );

        if (!withdraw.transactionSuccess()) {
            return fail(
                    "ECONOMY_WITHDRAW_FAILED"
            );
        }

        try {

            long transactionId =
                    record(
                            player.getUniqueId(),
                            null,
                            "ENFORCEMENT",
                            collected,
                            "PLAYER_TO_BANK:"
                                    + safe(bankId)
                    );

            return success(
                    transactionId,
                    collected
            );

        } catch (SQLException e) {

            economy.depositPlayer(
                    player,
                    collected.doubleValue()
            );

            return fail(
                    "TRANSACTION_LOG_FAILED"
            );
        }
    }

    // =========================================================
    // BANK BALANCE
    // =========================================================

    public BigDecimal getBankBalance(
            UUID bankId
    ) {

        if (bankId == null) {
            return BigDecimal.ZERO;
        }

        try (
                Connection connection =
                        plugin.getBankManager()
                                .getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(
                                """
                                SELECT money
                                FROM bank_data
                                WHERE uuid=?
                                """
                        )
        ) {

            statement.setString(
                    1,
                    bankId.toString()
            );

            try (
                    ResultSet result =
                            statement.executeQuery()
            ) {

                if (!result.next()) {
                    return BigDecimal.ZERO;
                }

                return money(
                        result.getDouble("money")
                );
            }

        } catch (SQLException e) {

            plugin.getLogger().severe(
                    "[TransactionService] Cannot read "
                            + "bank balance: "
                            + e.getMessage()
            );

            return BigDecimal.ZERO;
        }
    }

    public void addBankBalance(
            UUID bankId,
            BigDecimal amount
    ) throws SQLException {

        amount = money(amount);

        if (!positive(amount)) {
            throw new IllegalArgumentException(
                    "Amount must be positive"
            );
        }

        try (
                Connection connection =
                        plugin.getBankManager()
                                .getConnection()
        ) {

            ensureBank(
                    connection,
                    bankId
            );

            try (
                    PreparedStatement statement =
                            connection.prepareStatement(
                                    """
                                    UPDATE bank_data
                                    SET money = money + ?
                                    WHERE uuid=?
                                    """
                            )
            ) {

                statement.setDouble(
                        1,
                        amount.doubleValue()
                );

                statement.setString(
                        2,
                        bankId.toString()
                );

                if (statement.executeUpdate() != 1) {
                    throw new SQLException(
                            "Bank balance update failed"
                    );
                }
            }
        }
    }

    public void removeBankBalance(
            UUID bankId,
            BigDecimal amount
    )
            throws SQLException,
            InsufficientBankFundsException {

        amount = money(amount);

        if (!positive(amount)) {
            throw new IllegalArgumentException(
                    "Amount must be positive"
            );
        }

        try (
                Connection connection =
                        plugin.getBankManager()
                                .getConnection()
        ) {

            ensureBank(
                    connection,
                    bankId
            );

            BigDecimal balance =
                    readBankBalance(
                            connection,
                            bankId
                    );

            if (balance.compareTo(amount) < 0) {
                throw new InsufficientBankFundsException();
            }

            try (
                    PreparedStatement statement =
                            connection.prepareStatement(
                                    """
                                    UPDATE bank_data
                                    SET money = money - ?
                                    WHERE uuid=?
                                    """
                            )
            ) {

                statement.setDouble(
                        1,
                        amount.doubleValue()
                );

                statement.setString(
                        2,
                        bankId.toString()
                );

                statement.executeUpdate();
            }
        }
    }

    // =========================================================
    // TRANSACTION DATABASE
    // =========================================================

    private void createTransactionTable() {

        String sql = """
                CREATE TABLE IF NOT EXISTS
                kbank_transactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_uuid TEXT,
                    target_uuid TEXT,
                    type TEXT NOT NULL,
                    amount DOUBLE NOT NULL,
                    direction TEXT NOT NULL,
                    created_at BIGINT NOT NULL
                )
                """;

        try (
                Connection connection =
                        plugin.getBankManager()
                                .getConnection();

                Statement statement =
                        connection.createStatement()
        ) {

            statement.executeUpdate(sql);

        } catch (SQLException e) {

            throw new IllegalStateException(
                    "Cannot create kbank_transactions",
                    e
            );
        }
    }

    private long record(
            UUID source,
            UUID target,
            String type,
            BigDecimal amount,
            String direction
    ) throws SQLException {

        String sql = """
                INSERT INTO kbank_transactions
                (
                    source_uuid,
                    target_uuid,
                    type,
                    amount,
                    direction,
                    created_at
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """;

        try (
                Connection connection =
                        plugin.getBankManager()
                                .getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(
                                sql,
                                Statement.RETURN_GENERATED_KEYS
                        )
        ) {

            statement.setString(
                    1,
                    source == null
                            ? null
                            : source.toString()
            );

            statement.setString(
                    2,
                    target == null
                            ? null
                            : target.toString()
            );

            statement.setString(
                    3,
                    type
            );

            statement.setDouble(
                    4,
                    amount.doubleValue()
            );

            statement.setString(
                    5,
                    direction
            );

            statement.setLong(
                    6,
                    System.currentTimeMillis()
            );

            statement.executeUpdate();

            try (
                    ResultSet keys =
                            statement.getGeneratedKeys()
            ) {

                if (keys.next()) {
                    return keys.getLong(1);
                }
            }
        }

        return 0;
    }

    // =========================================================
    // INTERNAL
    // =========================================================

    private void ensureBank(
            Connection connection,
            UUID bankId
    ) throws SQLException {

        try (
                PreparedStatement statement =
                        connection.prepareStatement(
                                """
                                INSERT OR IGNORE INTO
                                bank_data(uuid, money)
                                VALUES (?, 0)
                                """
                        )
        ) {

            statement.setString(
                    1,
                    bankId.toString()
            );

            statement.executeUpdate();
        }
    }

    private BigDecimal readBankBalance(
            Connection connection,
            UUID bankId
    ) throws SQLException {

        try (
                PreparedStatement statement =
                        connection.prepareStatement(
                                """
                                SELECT money
                                FROM bank_data
                                WHERE uuid=?
                                """
                        )
        ) {

            statement.setString(
                    1,
                    bankId.toString()
            );

            try (
                    ResultSet result =
                            statement.executeQuery()
            ) {

                if (!result.next()) {
                    return BigDecimal.ZERO;
                }

                return money(
                        result.getDouble("money")
                );
            }
        }
    }

    private boolean hasBalance(
            Player player,
            BigDecimal amount
    ) {

        return money(
                economy.getBalance(player)
        ).compareTo(amount) >= 0;
    }

    private BigDecimal money(
            BigDecimal value
    ) {

        if (value == null) {
            return BigDecimal.ZERO.setScale(
                    SCALE,
                    RoundingMode.HALF_UP
            );
        }

        return value.setScale(
                SCALE,
                RoundingMode.HALF_UP
        );
    }

    private BigDecimal money(
            double value
    ) {

        return money(
                BigDecimal.valueOf(value)
        );
    }

    private boolean positive(
            BigDecimal value
    ) {

        return value != null
                && value.compareTo(
                        BigDecimal.ZERO
                ) > 0;
    }

    private String safe(
            String value
    ) {

        return value == null
                ? "SERVER_BANK"
                : value;
    }

    private TransactionResult success(
            long id,
            BigDecimal amount
    ) {

        return new TransactionResult(
                true,
                id,
                money(amount),
                "SUCCESS"
        );
    }

    private TransactionResult fail(
            String reason
    ) {

        return new TransactionResult(
                false,
                0,
                BigDecimal.ZERO,
                reason
        );
    }

    // =========================================================
    // RESULT
    // =========================================================

    public static final class TransactionResult {

        private final boolean success;
        private final long transactionId;
        private final BigDecimal amount;
        private final String reason;

        public TransactionResult(
                boolean success,
                long transactionId,
                BigDecimal amount,
                String reason
        ) {

            this.success = success;
            this.transactionId = transactionId;
            this.amount = amount;
            this.reason = reason;
        }

        public boolean isSuccess() {
            return success;
        }

        public long getTransactionId() {
            return transactionId;
        }

        public BigDecimal getAmount() {
            return amount;
        }

        public String getReason() {
            return reason;
        }
    }

    public static final class
    InsufficientBankFundsException
            extends Exception {

        public InsufficientBankFundsException() {
            super("Insufficient bank funds");
        }
    }
}