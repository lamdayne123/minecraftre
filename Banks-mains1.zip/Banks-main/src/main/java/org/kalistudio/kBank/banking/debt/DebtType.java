package org.kalistudio.kBank.banking.debt;
public enum DebtType { SERVER_LOAN, PRIVATE_BANK_LOAN, OWNER_BANKRUPTCY_DEBT }
