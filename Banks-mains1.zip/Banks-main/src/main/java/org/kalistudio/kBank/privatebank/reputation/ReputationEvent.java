package org.kalistudio.kBank.privatebank.reputation;
public enum ReputationEvent { POSITIVE_REVIEW, NEGATIVE_REVIEW, PAYMENT_FAILURE, DEPOSITOR_PAYOUT_FAILURE, SUCCESSFUL_OPERATION }
