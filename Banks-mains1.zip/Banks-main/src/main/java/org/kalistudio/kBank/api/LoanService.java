package org.kalistudio.kBank.api;
import java.math.BigDecimal;
import java.util.UUID;
import org.kalistudio.kBank.api.model.LoanSnapshot;
public interface LoanService {
    LoanSnapshot getLoan(UUID borrower);
    LoanSnapshot createLoan(UUID borrower, String bankId, BigDecimal principal);
    boolean repayLoan(UUID borrower, BigDecimal amount);
    boolean transferLoanToServer(UUID borrower);
}
