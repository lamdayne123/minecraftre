package org.kalistudio.kBank.service;

import org.kalistudio.kBank.KBank;
import org.kalistudio.kBank.bank.BankManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

public class InterestService {

    private final KBank plugin;
    private final BankManager bankManager;

    private double dailyInterestPercent;

    public InterestService(KBank plugin) {
        this.plugin = plugin;
        this.bankManager = plugin.getBankManager();

        this.dailyInterestPercent = plugin.getConfig()
                .getDouble(
                        "deposit.daily-interest-percent",
                        0.2
                );

        createTable();
    }

    // =========================================================
    // DATABASE
    // =========================================================

    /**
     * Tạo bảng lưu ngày tính lãi cuối cùng.
     */
    private void createTable() {

        String sql = """
                CREATE TABLE IF NOT EXISTS bank_interest (
                    uuid TEXT PRIMARY KEY,
                    last_interest_date TEXT NOT NULL
                )
                """;

        try (
                Connection connection = bankManager.getConnection();
                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.executeUpdate();

        } catch (SQLException e) {

            plugin.getLogger().severe(
                    "[kBank] Không thể tạo bảng bank_interest: "
                            + e.getMessage()
            );
        }
    }

    // =========================================================
    // INTEREST CALCULATION
    // =========================================================

    /**
     * Tính lãi cho một ngày.
     *
     * Ví dụ:
     *
     * balance = 1,000,000
     * interest = 0.2%
     *
     * => 2,000
     */
    public double calculateDailyInterest(double balance) {

        if (balance <= 0) {
            return 0.0D;
        }

        if (dailyInterestPercent <= 0) {
            return 0.0D;
        }

        return balance
                * (dailyInterestPercent / 100.0D);
    }

    // =========================================================
    // APPLY INTEREST
    // =========================================================

    /**
     * Tính và trả lãi cho player.
     *
     * Luồng:
     *
     * Server Bank
     *      ↓
     *   trừ tiền
     *      ↓
     * Player Bank
     *
     * Không tự tạo tiền.
     *
     * Lãi được tính theo số ngày đã trôi qua kể từ
     * lần tính lãi cuối cùng.
     */
    public synchronized double applyInterest(UUID uuid) {

        if (uuid == null) {
            return 0.0D;
        }

        // -----------------------------------------------------
        // Lấy số dư player
        // -----------------------------------------------------

        double balance =
                bankManager.getMoney(uuid);

        LocalDate today =
                LocalDate.now();

        /*
         * Không có tiền thì vẫn cập nhật ngày.
         *
         * Điều này tránh việc player để tài khoản 0
         * trong 30 ngày rồi sau đó nạp tiền và nhận
         * lãi cho cả 30 ngày trước đó.
         */
        if (balance <= 0) {

            updateLastInterestDate(
                    uuid,
                    today
            );

            return 0.0D;
        }

        // -----------------------------------------------------
        // Lấy ngày tính lãi cuối cùng
        // -----------------------------------------------------

        LocalDate lastDate =
                getLastInterestDate(uuid);

        /*
         * Account mới chưa có lịch sử lãi.
         *
         * Không trả lãi ngay lần đầu.
         * Chỉ bắt đầu đếm từ hôm nay.
         */
        if (lastDate == null) {

            updateLastInterestDate(
                    uuid,
                    today
            );

            return 0.0D;
        }

        // -----------------------------------------------------
        // Tính số ngày đã trôi qua
        // -----------------------------------------------------

        long days =
                ChronoUnit.DAYS.between(
                        lastDate,
                        today
                );

        if (days <= 0) {
            return 0.0D;
        }

        // -----------------------------------------------------
        // Tính lãi
        // -----------------------------------------------------

        double dailyInterest =
                calculateDailyInterest(balance);

        if (dailyInterest <= 0) {

            updateLastInterestDate(
                    uuid,
                    today
            );

            return 0.0D;
        }

        /*
         * Lãi đơn.
         *
         * Không compound.
         *
         * Ví dụ:
         *
         * 1,000,000
         * 0.2% = 2,000/ngày
         *
         * 3 ngày:
         *
         * 2,000 × 3 = 6,000
         */
        double interest =
                dailyInterest * days;

        if (interest <= 0) {

            updateLastInterestDate(
                    uuid,
                    today
            );

            return 0.0D;
        }

        // -----------------------------------------------------
        // Server Bank phải đủ tiền
        // -----------------------------------------------------

        double serverBankBalance =
                bankManager.getServerBankBalance();

        if (serverBankBalance < interest) {

            plugin.getLogger().warning(
                    "[kBank] Server Bank không đủ tiền "
                            + "để trả lãi cho "
                            + uuid
                            + ". Cần: "
                            + interest
                            + ", hiện có: "
                            + serverBankBalance
            );

            /*
             * Không cập nhật last_interest_date.
             *
             * Nếu Server Bank được bổ sung tiền sau đó,
             * player vẫn có thể nhận phần lãi chưa trả.
             */
            return 0.0D;
        }

        // -----------------------------------------------------
        // Trừ Server Bank
        // -----------------------------------------------------

        boolean removed =
                bankManager.removeServerBankMoney(
                        interest
                );

        if (!removed) {

            plugin.getLogger().severe(
                    "[kBank] Không thể trừ "
                            + interest
                            + " khỏi Server Bank "
                            + "khi trả lãi cho "
                            + uuid
            );

            return 0.0D;
        }

        // -----------------------------------------------------
        // Cộng Player Bank
        // -----------------------------------------------------

        boolean deposited =
                bankManager.addMoney(
                        uuid,
                        interest
                );

        if (!deposited) {

            /*
             * Player Bank thất bại.
             *
             * Rollback tiền Server Bank.
             */
            boolean rollback =
                    bankManager.addServerBankMoney(
                            interest
                    );

            if (rollback) {

                plugin.getLogger().severe(
                        "[kBank] Interest transaction "
                                + "thất bại cho "
                                + uuid
                                + ". Đã rollback "
                                + interest
                                + " về Server Bank."
                );

            } else {

                plugin.getLogger().severe(
                        "[kBank] CRITICAL: Không thể "
                                + "cộng lãi cho "
                                + uuid
                                + " và cũng không thể "
                                + "rollback Server Bank. "
                                + "Amount: "
                                + interest
                );
            }

            return 0.0D;
        }

        // -----------------------------------------------------
        // Transaction thành công
        // -----------------------------------------------------

        updateLastInterestDate(
                uuid,
                today
        );

        plugin.getLogger().info(
                "[kBank] Player "
                        + uuid
                        + " nhận "
                        + String.format(
                                "%.2f",
                                interest
                        )
                        + " tiền lãi cho "
                        + days
                        + " ngày."
        );

        return interest;
    }

    // =========================================================
    // LAST INTEREST DATE
    // =========================================================

    /**
     * Lấy ngày tính lãi cuối cùng.
     */
    private LocalDate getLastInterestDate(
            UUID uuid
    ) {

        String sql = """
                SELECT last_interest_date
                FROM bank_interest
                WHERE uuid = ?
                """;

        try (
                Connection connection =
                        bankManager.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setString(
                    1,
                    uuid.toString()
            );

            try (
                    ResultSet result =
                            statement.executeQuery()
            ) {

                if (!result.next()) {
                    return null;
                }

                String date =
                        result.getString(
                                "last_interest_date"
                        );

                try {

                    return LocalDate.parse(
                            date
                    );

                } catch (Exception ignored) {

                    plugin.getLogger().warning(
                            "[kBank] Ngày tính lãi không hợp lệ "
                                    + "cho "
                                    + uuid
                    );

                    return null;
                }
            }

        } catch (SQLException e) {

            plugin.getLogger().severe(
                    "[kBank] Không thể đọc ngày tính lãi "
                            + "của "
                            + uuid
                            + ": "
                            + e.getMessage()
            );

            return null;
        }
    }

    /**
     * Cập nhật ngày tính lãi cuối cùng.
     */
    private void updateLastInterestDate(
            UUID uuid,
            LocalDate date
    ) {

        String sql = """
                INSERT INTO bank_interest (
                    uuid,
                    last_interest_date
                )
                VALUES (?, ?)
                ON CONFLICT(uuid)
                DO UPDATE SET
                    last_interest_date =
                        excluded.last_interest_date
                """;

        try (
                Connection connection =
                        bankManager.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setString(
                    1,
                    uuid.toString()
            );

            statement.setString(
                    2,
                    date.toString()
            );

            statement.executeUpdate();

        } catch (SQLException e) {

            plugin.getLogger().severe(
                    "[kBank] Không thể cập nhật ngày tính lãi "
                            + "của "
                            + uuid
                            + ": "
                            + e.getMessage()
            );
        }
    }

    // =========================================================
    // CONFIG
    // =========================================================

    /**
     * Lấy lãi suất hiện tại.
     */
    public double getDailyInterestPercent() {

        return dailyInterestPercent;
    }

    /**
     * Reload lãi suất từ config.yml.
     */
    public void reload() {

        dailyInterestPercent =
                plugin.getConfig()
                        .getDouble(
                                "deposit.daily-interest-percent",
                                0.2
                        );
    }
}