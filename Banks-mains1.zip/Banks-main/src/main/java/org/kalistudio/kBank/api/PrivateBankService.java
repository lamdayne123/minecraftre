package org.kalistudio.kBank.api;
import java.math.BigDecimal;
import java.util.UUID;
import org.kalistudio.kBank.api.model.PrivateBankSnapshot;
public interface PrivateBankService {
    PrivateBankSnapshot getBank(String bankId);
    PrivateBankSnapshot createBank(UUID owner, String name, BigDecimal capital);
    boolean exists(String bankId);
}
