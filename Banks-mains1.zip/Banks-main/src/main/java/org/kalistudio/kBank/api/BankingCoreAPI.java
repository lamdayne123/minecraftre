package org.kalistudio.kBank.api;
public interface BankingCoreAPI {
    DebtService getDebtService();
    LoanService getLoanService();
}
