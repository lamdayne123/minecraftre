package org.kalistudio.kBank.privatebank.review;
import java.util.UUID;
public record BankReview(UUID player, String bankId, int stars, long createdAt) {}
