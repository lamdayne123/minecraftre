package org.kalistudio.kBank.api.event;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.kalistudio.kBank.api.model.DebtSnapshot;

public final class DebtCreatedEvent extends Event {
    private static final HandlerList HANDLERS = new HandlerList();
    private final DebtSnapshot snapshot;
    public DebtCreatedEvent(DebtSnapshot snapshot) { this.snapshot = snapshot; }
    public DebtSnapshot getSnapshot() { return snapshot; }
    @Override public HandlerList getHandlers() { return HANDLERS; }
    public static HandlerList getHandlerList() { return HANDLERS; }
}
