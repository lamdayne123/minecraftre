package org.kalistudio.kBank.bank;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.kalistudio.kBank.KBank;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class BankManager {

    private static final String SERVER_BANK_UUID =
            "00000000-0000-0000-0000-000000000001";

    private static final double SERVER_BANK_INITIAL_CAPITAL =
            10_000_000.00D;

    private final KBank plugin;

    private final Map<UUID, BankAccount> accounts =
            new HashMap<>();

    public BankManager(KBank plugin) {

        if (plugin == null) {
            throw new IllegalArgumentException(
                    "plugin cannot be null"
            );
        }

        this.plugin = plugin;

        createTable();
        initializeServerBank();
    }

    // =========================================================
    // DATABASE
    // =========================================================

    /**
     * Mỗi thao tác database tự mở connection mới
     * và tự đóng bằng try-with-resources.
     *
     * Không giữ connection lâu dài trong BankManager.
     */
    private Connection getDatabaseConnection()
            throws SQLException {

        if (plugin.getDatabase() == null) {
            throw new SQLException(
                    "DatabaseManager chưa được khởi tạo"
            );
        }

        return plugin.getDatabase()
                .getConnection();
    }

    private void createTable() {

        String sql =
                """
                CREATE TABLE IF NOT EXISTS bank_data (
                    uuid TEXT PRIMARY KEY,
                    money DOUBLE NOT NULL DEFAULT 0
                )
                """;

        try (
                Connection connection =
                        getDatabaseConnection();

                Statement statement =
                        connection.createStatement()
        ) {

            statement.executeUpdate(sql);

        } catch (SQLException e) {

            throw new IllegalStateException(
                    "Không thể tạo bảng bank_data",
                    e
            );
        }
    }

    // =========================================================
    // SERVER BANK
    // =========================================================

    public UUID getServerBankUUID() {

        return UUID.fromString(
                SERVER_BANK_UUID
        );
    }

    /**
     * Khởi tạo Server Bank một lần duy nhất.
     *
     * Restart server sẽ không cộng thêm vốn.
     */
    private void initializeServerBank() {

        UUID serverBank =
                getServerBankUUID();

        String sql =
                """
                INSERT OR IGNORE INTO bank_data
                (uuid, money)
                VALUES (?, ?)
                """;

        try (
                Connection connection =
                        getDatabaseConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setString(
                    1,
                    serverBank.toString()
            );

            statement.setDouble(
                    2,
                    SERVER_BANK_INITIAL_CAPITAL
            );

            int affected =
                    statement.executeUpdate();

            if (affected == 1) {

                plugin.getLogger().info(
                        "[kBank] Server Bank được khởi tạo "
                                + "với vốn "
                                + SERVER_BANK_INITIAL_CAPITAL
                );
            }

        } catch (SQLException e) {

            throw new IllegalStateException(
                    "Không thể khởi tạo Server Bank",
                    e
            );
        }
    }

    public double getServerBankBalance() {

        return getMoney(
                getServerBankUUID()
        );
    }

    public boolean addServerBankMoney(
            double amount
    ) {

        return addMoney(
                getServerBankUUID(),
                amount
        );
    }

    public boolean removeServerBankMoney(
            double amount
    ) {

        return removeMoney(
                getServerBankUUID(),
                amount
        );
    }

    // =========================================================
    // ACCOUNT DATABASE
    // =========================================================

    private void ensureAccount(UUID uuid) {

        if (uuid == null) {
            return;
        }

        String sql =
                """
                INSERT OR IGNORE INTO bank_data
                (uuid, money)
                VALUES (?, 0)
                """;

        try (
                Connection connection =
                        getDatabaseConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setString(
                    1,
                    uuid.toString()
            );

            statement.executeUpdate();

        } catch (SQLException e) {

            throw new IllegalStateException(
                    "Không thể tạo bank account "
                            + uuid,
                    e
            );
        }
    }

    // =========================================================
    // MONEY
    // =========================================================

    /**
     * Lấy số dư thật từ bank_data.
     *
     * Database là nguồn dữ liệu chính.
     */
    public synchronized double getMoney(
            UUID uuid
    ) {

        if (uuid == null) {
            return 0.0D;
        }

        ensureAccount(uuid);

        String sql =
                """
                SELECT money
                FROM bank_data
                WHERE uuid = ?
                """;

        try (
                Connection connection =
                        getDatabaseConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setString(
                    1,
                    uuid.toString()
            );

            try (
                    ResultSet result =
                            statement.executeQuery()
            ) {

                if (result.next()) {
                    return result.getDouble(
                            "money"
                    );
                }
            }

        } catch (SQLException e) {

            plugin.getLogger().severe(
                    "[kBank] Không thể đọc số dư "
                            + uuid
                            + ": "
                            + e.getMessage()
            );
        }

        return 0.0D;
    }

    /**
     * Cộng tiền trực tiếp vào bank.
     *
     * Không động tới Vault.
     */
    public synchronized boolean addMoney(
            UUID uuid,
            double amount
    ) {

        if (uuid == null || amount <= 0) {
            return false;
        }

        ensureAccount(uuid);

        String sql =
                """
                UPDATE bank_data
                SET money = money + ?
                WHERE uuid = ?
                """;

        try (
                Connection connection =
                        getDatabaseConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setDouble(
                    1,
                    amount
            );

            statement.setString(
                    2,
                    uuid.toString()
            );

            return statement.executeUpdate() == 1;

        } catch (SQLException e) {

            plugin.getLogger().severe(
                    "[kBank] Không thể cộng tiền: "
                            + e.getMessage()
            );

            return false;
        }
    }

    /**
     * Trừ tiền khỏi bank.
     *
     * Không bao giờ cho số dư âm.
     */
    public synchronized boolean removeMoney(
            UUID uuid,
            double amount
    ) {

        if (uuid == null || amount <= 0) {
            return false;
        }

        ensureAccount(uuid);

        String sql =
                """
                UPDATE bank_data
                SET money = money - ?
                WHERE uuid = ?
                AND money >= ?
                """;

        try (
                Connection connection =
                        getDatabaseConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setDouble(
                    1,
                    amount
            );

            statement.setString(
                    2,
                    uuid.toString()
            );

            statement.setDouble(
                    3,
                    amount
            );

            return statement.executeUpdate() == 1;

        } catch (SQLException e) {

            plugin.getLogger().severe(
                    "[kBank] Không thể trừ tiền: "
                            + e.getMessage()
            );

            return false;
        }
    }

    // =========================================================
    // PLAYER -> BANK
    // =========================================================

    /**
     * API cũ:
     *
     * Player -> Bank
     *
     * Vault phải rút thành công trước,
     * sau đó mới cộng tiền vào bank.
     */
    public synchronized void depositMoney(
            Player player,
            double amount
    ) {

        if (player == null || amount <= 0) {
            return;
        }

        if (plugin.getEconomy() == null) {
            return;
        }

        if (plugin.getEconomy()
                .getBalance(player) < amount) {
            return;
        }

        var response =
                plugin.getEconomy()
                        .withdrawPlayer(
                                player,
                                amount
                        );

        if (!response.transactionSuccess()) {
            return;
        }

        if (!addMoney(
                player.getUniqueId(),
                amount
        )) {

            /*
             * Database thất bại.
             * Cố gắng hoàn tiền Vault.
             */
            plugin.getEconomy()
                    .depositPlayer(
                            player,
                            amount
                    );

            plugin.getLogger().severe(
                    "[kBank] Deposit database failure. "
                            + "Đã cố gắng hoàn tiền cho "
                            + player.getName()
            );
        }
    }

    // =========================================================
    // BANK -> PLAYER
    // =========================================================

    /**
     * API cũ:
     *
     * Bank -> Player
     */
    public synchronized void withdrawMoney(
            Player player,
            double amount
    ) {

        if (player == null || amount <= 0) {
            return;
        }

        if (plugin.getEconomy() == null) {
            return;
        }

        UUID uuid =
                player.getUniqueId();

        if (!removeMoney(
                uuid,
                amount
        )) {
            return;
        }

        var response =
                plugin.getEconomy()
                        .depositPlayer(
                                player,
                                amount
                        );

        if (!response.transactionSuccess()) {

            /*
             * Vault thất bại.
             * Rollback tiền ngân hàng.
             */
            addMoney(
                    uuid,
                    amount
            );

            plugin.getLogger().severe(
                    "[kBank] Withdraw Vault failure. "
                            + "Đã rollback bank balance."
            );
        }
    }

    // =========================================================
    // UUID -> BANK
    // =========================================================

    /**
     * Cộng tiền trực tiếp vào bank account.
     *
     * Không sử dụng Vault.
     */
    public synchronized void depositMoney(
            UUID uuid,
            double amount
    ) {

        addMoney(
                uuid,
                amount
        );
    }

    // =========================================================
    // ACCOUNT MANAGEMENT
    // =========================================================

    public Map<UUID, BankAccount> getAccounts() {
        return accounts;
    }

    public boolean hasAccount(
            UUID uuid
    ) {

        if (uuid == null) {
            return false;
        }

        return accounts.containsKey(uuid);
    }

    public void createAccount(
            Player player
    ) {

        if (player == null) {
            return;
        }

        UUID uuid =
                player.getUniqueId();

        if (hasAccount(uuid)) {
            return;
        }

        String ownerName =
                player.getName();

        String accountNumber =
                generateAccountNumber();

        Date createdAt =
                new Date();

        BankAccount account =
                new BankAccount(
                        ownerName,
                        accountNumber,
                        createdAt,
                        getMoney(uuid)
                );

        accounts.put(
                uuid,
                account
        );

        saveAccountToFile(
                uuid,
                account
        );
    }

    /**
     * Sinh số tài khoản 12 chữ số.
     */
    private String generateAccountNumber() {

        StringBuilder builder =
                new StringBuilder(12);

        for (int i = 0; i < 12; i++) {

            builder.append(
                    (int)
                            (Math.random() * 10)
            );
        }

        return builder.toString();
    }

    public BankAccount getAccount(
            UUID uuid
    ) {

        return accounts.get(uuid);
    }

    // =========================================================
    // YAML ACCOUNT METADATA
    // =========================================================

    public void saveAccountToFile(
            UUID uuid,
            BankAccount account
    ) {

        if (uuid == null || account == null) {
            return;
        }

        File file =
                new File(
                        plugin.getDataFolder(),
                        "accounts.yml"
                );

        YamlConfiguration config =
                YamlConfiguration
                        .loadConfiguration(file);

        String path =
                uuid.toString();

        config.set(
                path + ".owner",
                account.ownerName
        );

        config.set(
                path + ".accountNumber",
                account.accountNumber
        );

        config.set(
                path + ".createdAt",
                account.createdAt.getTime()
        );

        /*
         * Chỉ lưu cache.
         * Số dư thật vẫn nằm trong SQLite.
         */
        config.set(
                path + ".balance",
                getMoney(uuid)
        );

        try {

            config.save(file);

        } catch (IOException e) {

            plugin.getLogger().severe(
                    "[kBank] Không thể lưu accounts.yml: "
                            + e.getMessage()
            );
        }
    }

    public void loadAccounts() {

        accounts.clear();

        File file =
                new File(
                        plugin.getDataFolder(),
                        "accounts.yml"
                );

        if (!file.exists()) {
            return;
        }

        YamlConfiguration config =
                YamlConfiguration
                        .loadConfiguration(file);

        for (String uuidString :
                config.getKeys(false)) {

            try {

                UUID uuid =
                        UUID.fromString(
                                uuidString
                        );

                String owner =
                        config.getString(
                                uuidString
                                        + ".owner",
                                "Unknown"
                        );

                String accountNumber =
                        config.getString(
                                uuidString
                                        + ".accountNumber",
                                ""
                        );

                long createdAt =
                        config.getLong(
                                uuidString
                                        + ".createdAt"
                        );

                /*
                 * Không lấy balance từ YAML.
                 */
                double balance =
                        getMoney(uuid);

                BankAccount account =
                        new BankAccount(
                                owner,
                                accountNumber,
                                new Date(
                                        createdAt
                                ),
                                balance
                        );

                accounts.put(
                        uuid,
                        account
                );

            } catch (Exception e) {

                plugin.getLogger().warning(
                        "[kBank] Không thể load account "
                                + uuidString
                                + ": "
                                + e.getMessage()
                );
            }
        }

        Bukkit.getLogger().info(
                "[kBank] Đã tải "
                        + accounts.size()
                        + " tài khoản ngân hàng."
        );
    }

    public void saveAllAccounts() {

        File file =
                new File(
                        plugin.getDataFolder(),
                        "accounts.yml"
                );

        YamlConfiguration config =
                new YamlConfiguration();

        for (Map.Entry<UUID, BankAccount> entry :
                accounts.entrySet()) {

            UUID uuid =
                    entry.getKey();

            BankAccount account =
                    entry.getValue();

            String path =
                    uuid.toString();

            config.set(
                    path + ".owner",
                    account.ownerName
            );

            config.set(
                    path + ".accountNumber",
                    account.accountNumber
            );

            config.set(
                    path + ".createdAt",
                    account.createdAt.getTime()
            );

            /*
             * Đồng bộ cache với database.
             */
            config.set(
                    path + ".balance",
                    getMoney(uuid)
            );
        }

        try {

            config.save(file);

        } catch (IOException e) {

            plugin.getLogger().severe(
                    "[kBank] Không thể lưu accounts.yml: "
                            + e.getMessage()
            );
        }
    }

    // =========================================================
    // CONNECTION
    // =========================================================

    /**
     * API tương thích với TransactionService
     * và các service khác.
     *
     * Connection được tạo mới mỗi lần gọi.
     *
     * Caller phải đóng connection.
     */
    public Connection getConnection()
            throws SQLException {

        return getDatabaseConnection();
    }
}