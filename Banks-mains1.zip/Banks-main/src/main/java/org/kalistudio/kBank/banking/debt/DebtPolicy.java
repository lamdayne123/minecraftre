package org.kalistudio.kBank.banking.debt;
import java.math.BigDecimal;
public final class DebtPolicy {
    private DebtPolicy() {}
    public static final int GRACE_DAYS = 3;
    public static final BigDecimal MIN_DAILY_PAYMENT_PERCENT = new BigDecimal("10.0");
    public static final int GRACE_USES = 2;
    public static final int BAD_DEBT_DAYS_BEFORE_ENFORCEMENT = 3;
    public static final BigDecimal ENFORCEMENT_PERCENT = new BigDecimal("20.0");
}
