package org.kalistudio.kBank.loan;

import org.kalistudio.kBank.KBank;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public final class DatabaseManager {

    private final KBank plugin;
    private final File dbFile;
    private final String url;

    public DatabaseManager(KBank plugin) {

        if (plugin == null) {
            throw new IllegalArgumentException(
                    "plugin cannot be null"
            );
        }

        this.plugin = plugin;

        if (!plugin.getDataFolder().exists()
                && !plugin.getDataFolder().mkdirs()) {

            throw new IllegalStateException(
                    "Không thể tạo thư mục plugin: "
                            + plugin.getDataFolder()
            );
        }

        /*
         * Tất cả hệ thống kBank dùng chung database này.
         *
         * bank_data
         * kbank_transactions
         * bank_interest
         * savings
         * loans
         */
        this.dbFile = new File(
                plugin.getDataFolder(),
                "data.db"
        );

        this.url =
                "jdbc:sqlite:"
                        + dbFile.getAbsolutePath();

        plugin.getLogger().info(
                "[kBank] SQLite database: "
                        + dbFile.getAbsolutePath()
        );

        testConnection();
    }

    /**
     * Mở một connection mới.
     *
     * Caller phải đóng connection bằng
     * try-with-resources.
     */
    public Connection getConnection()
            throws SQLException {

        Connection connection =
                DriverManager.getConnection(url);

        configureConnection(connection);

        return connection;
    }

    /**
     * Cấu hình connection SQLite.
     */
    private void configureConnection(
            Connection connection
    ) throws SQLException {

        try (Statement statement =
                     connection.createStatement()) {

            statement.execute(
                    "PRAGMA foreign_keys = ON"
            );

            statement.execute(
                    "PRAGMA busy_timeout = 5000"
            );

            statement.execute(
                    "PRAGMA journal_mode = WAL"
            );

            statement.execute(
                    "PRAGMA synchronous = NORMAL"
            );
        }
    }

    /**
     * Kiểm tra database khi plugin khởi động.
     */
    private void testConnection() {

        try (Connection connection =
                     getConnection()) {

            plugin.getLogger().info(
                    "[kBank] SQLite connected successfully."
            );

        } catch (SQLException e) {

            throw new IllegalStateException(
                    "Không thể kết nối SQLite database: "
                            + dbFile.getAbsolutePath(),
                    e
            );
        }
    }

    public File getDatabaseFile() {
        return dbFile;
    }

    public String getUrl() {
        return url;
    }
}