package org.kalistudio.kBank.privatebank;
import java.util.UUID;
public record PrivateBankOwner(UUID ownerId) {}
