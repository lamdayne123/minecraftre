package org.kalistudio.kBank.privatebank.reputation;
import java.util.Objects;
public final class BankReputation {
    private double value;
    public BankReputation(double value) { this.value = value; }
    public double getValue() { return value; }
    public void setValue(double value) { this.value = value; }
    public void add(double amount) { value += amount; }
    public boolean isBankrupt() { return value < 1.0; }
    @Override public boolean equals(Object o) { return o instanceof BankReputation other && Double.compare(value, other.value) == 0; }
    @Override public int hashCode() { return Objects.hash(value); }
}
