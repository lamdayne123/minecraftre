package org.kalistudio.kBank.banking;
import java.math.BigDecimal;
public final class BankingPolicy {
    private BankingPolicy() {}
    public static final long INITIAL_SERVER_CAPITAL = 10_000_000L;
    public static final BigDecimal DAILY_DEPOSIT_INTEREST_PERCENT = new BigDecimal("0.2");
}
