package org.kalistudio.kBank.loan;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.kalistudio.kBank.KBank;
import org.kalistudio.kBank.utils.ChatUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SavingManager {

    private final KBank plugin;

    private final Map<UUID, Boolean> selecting =
            new HashMap<>();

    private static final long DAY_MILLIS =
            24L * 60L * 60L * 1000L;

    private static final long MONTH_MILLIS =
            30L * DAY_MILLIS;

    public SavingManager(KBank plugin) {

        if (plugin == null) {
            throw new IllegalArgumentException(
                    "plugin cannot be null"
            );
        }

        this.plugin = plugin;

        setupDatabase();
    }

    // =========================================================
    // SELECTING PERIOD
    // =========================================================

    public void setSelectingPeriod(
            UUID uuid,
            boolean value
    ) {

        if (uuid == null) {
            return;
        }

        if (value) {
            selecting.put(uuid, true);
        } else {
            selecting.remove(uuid);
        }
    }

    public boolean isSelecting(UUID uuid) {

        if (uuid == null) {
            return false;
        }

        return selecting.getOrDefault(
                uuid,
                false
        );
    }

    // =========================================================
    // DATABASE
    // =========================================================

    private void setupDatabase() {

        String sql = """
                CREATE TABLE IF NOT EXISTS savings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    uuid TEXT NOT NULL UNIQUE,
                    amount DOUBLE NOT NULL DEFAULT 0,
                    months INTEGER NOT NULL,
                    created_at BIGINT NOT NULL,
                    rate DOUBLE NOT NULL,
                    mature_at BIGINT NOT NULL
                )
                """;

        try (
                Connection connection =
                        plugin.getDatabase().getConnection();
                Statement statement =
                        connection.createStatement()
        ) {

            if (connection == null) {
                throw new SQLException(
                        "Database connection is null"
                );
            }

            statement.executeUpdate(sql);

        } catch (SQLException e) {

            throw new IllegalStateException(
                    "Không thể tạo bảng savings",
                    e
            );
        }
    }

    // =========================================================
    // SAVE DEPOSIT
    // =========================================================

    /**
     * Chỉ xử lý database.
     *
     * KHÔNG trừ tiền player ở đây.
     *
     * @return true nếu lưu thành công.
     */
    public synchronized boolean saveDeposit(
            UUID uuid,
            double amount,
            int months
    ) {

        if (uuid == null) {
            return false;
        }

        if (!Double.isFinite(amount)
                || amount <= 0) {
            return false;
        }

        if (!isValidPeriod(months)) {
            return false;
        }

        long now =
                System.currentTimeMillis();

        long matureAt =
                now + (months * MONTH_MILLIS);

        double rate =
                getRate(months);

        if (!Double.isFinite(rate)
                || rate < 0) {
            rate = 0;
        }

        String selectSql = """
                SELECT amount
                FROM savings
                WHERE uuid = ?
                LIMIT 1
                """;

        String updateSql = """
                UPDATE savings
                SET amount = ?,
                    months = ?,
                    created_at = ?,
                    rate = ?,
                    mature_at = ?
                WHERE uuid = ?
                """;

        String insertSql = """
                INSERT INTO savings
                (
                    uuid,
                    amount,
                    months,
                    created_at,
                    rate,
                    mature_at
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """;

        try (
                Connection connection =
                        plugin.getDatabase().getConnection()
        ) {

            if (connection == null) {
                return false;
            }

            connection.setAutoCommit(false);

            try {

                double oldAmount = 0D;
                boolean exists = false;

                try (
                        PreparedStatement statement =
                                connection.prepareStatement(
                                        selectSql
                                )
                ) {

                    statement.setString(
                            1,
                            uuid.toString()
                    );

                    try (
                            ResultSet rs =
                                    statement.executeQuery()
                    ) {

                        if (rs.next()) {

                            exists = true;

                            oldAmount =
                                    rs.getDouble(
                                            "amount"
                                    );
                        }
                    }
                }

                double newAmount =
                        oldAmount + amount;

                if (!Double.isFinite(newAmount)
                        || newAmount <= 0) {

                    throw new SQLException(
                            "Số tiền saving không hợp lệ"
                    );
                }

                if (exists) {

                    try (
                            PreparedStatement statement =
                                    connection.prepareStatement(
                                            updateSql
                                    )
                    ) {

                        statement.setDouble(
                                1,
                                newAmount
                        );

                        statement.setInt(
                                2,
                                months
                        );

                        statement.setLong(
                                3,
                                now
                        );

                        statement.setDouble(
                                4,
                                rate
                        );

                        statement.setLong(
                                5,
                                matureAt
                        );

                        statement.setString(
                                6,
                                uuid.toString()
                        );

                        if (statement.executeUpdate()
                                != 1) {

                            throw new SQLException(
                                    "Không thể cập nhật saving"
                            );
                        }
                    }

                } else {

                    try (
                            PreparedStatement statement =
                                    connection.prepareStatement(
                                            insertSql
                                    )
                    ) {

                        statement.setString(
                                1,
                                uuid.toString()
                        );

                        statement.setDouble(
                                2,
                                amount
                        );

                        statement.setInt(
                                3,
                                months
                        );

                        statement.setLong(
                                4,
                                now
                        );

                        statement.setDouble(
                                5,
                                rate
                        );

                        statement.setLong(
                                6,
                                matureAt
                        );

                        statement.executeUpdate();
                    }
                }

                connection.commit();

                return true;

            } catch (Exception e) {

                try {
                    connection.rollback();
                } catch (SQLException ignored) {
                }

                plugin.getLogger().severe(
                        "[kBank] Không thể lưu saving "
                                + uuid
                                + ": "
                                + e.getMessage()
                );

                return false;

            } finally {

                try {
                    connection.setAutoCommit(true);
                } catch (SQLException ignored) {
                }
            }

        } catch (SQLException e) {

            plugin.getLogger().severe(
                    "[kBank] Saving database error: "
                            + e.getMessage()
            );

            return false;
        }
    }

    // =========================================================
    // GET SAVING
    // =========================================================

    public SavingData getSaving(UUID uuid) {

        if (uuid == null) {
            return null;
        }

        String sql = """
                SELECT
                    uuid,
                    amount,
                    months,
                    created_at,
                    mature_at,
                    rate
                FROM savings
                WHERE uuid = ?
                LIMIT 1
                """;

        try (
                Connection connection =
                        plugin.getDatabase().getConnection()
        ) {

            if (connection == null) {
                return null;
            }

            try (
                    PreparedStatement statement =
                            connection.prepareStatement(sql)
            ) {

                statement.setString(
                        1,
                        uuid.toString()
                );

                try (
                        ResultSet rs =
                                statement.executeQuery()
                ) {

                    if (!rs.next()) {
                        return null;
                    }

                    return new SavingData(
                            uuid,
                            rs.getDouble("amount"),
                            rs.getInt("months"),
                            rs.getLong("created_at"),
                            rs.getLong("mature_at"),
                            rs.getDouble("rate")
                    );
                }
            }

        } catch (SQLException e) {

            plugin.getLogger().severe(
                    "[kBank] Không thể đọc saving "
                            + uuid
                            + ": "
                            + e.getMessage()
            );

            return null;
        }
    }

    // =========================================================
    // WITHDRAW AT MATURITY
    // =========================================================

    public synchronized void withdrawSaving(
            UUID playerId
    ) {

        if (playerId == null) {
            return;
        }

        Player player =
                Bukkit.getPlayer(playerId);

        if (player == null) {
            return;
        }

        SavingData saving =
                getSaving(playerId);

        if (saving == null) {

            player.sendMessage(
                    ChatUtil.color(
                            "&cBạn không có khoản tiết kiệm nào."
                    )
            );

            return;
        }

        long now =
                System.currentTimeMillis();

        if (now < saving.matureAt) {

            long daysLeft =
                    (saving.matureAt - now
                            + DAY_MILLIS - 1)
                            / DAY_MILLIS;

            player.sendMessage(
                    ChatUtil.color(
                            "&eBạn chưa đến hạn rút. "
                                    + "Còn khoảng &c"
                                    + daysLeft
                                    + " &engày nữa."
                    )
            );

            player.playSound(
                    player.getLocation(),
                    Sound.BLOCK_NOTE_BLOCK_BASS,
                    1.0f,
                    0.7f
            );

            return;
        }

        double interest =
                saving.amount
                        * saving.rate
                        * saving.months;

        double total =
                saving.amount + interest;

        if (!Double.isFinite(total)
                || total <= 0) {

            player.sendMessage(
                    ChatUtil.color(
                            "&cKhoản tiết kiệm không hợp lệ."
                    )
            );

            return;
        }

        /*
         * Saving -> Bank.
         *
         * KHÔNG qua Vault.
         */
        boolean deposited =
                plugin.getBankManager()
                        .addMoney(
                                playerId,
                                total
                        );

        if (!deposited) {

            player.sendMessage(
                    ChatUtil.color(
                            "&cKhông thể chuyển tiền tiết kiệm vào ngân hàng."
                    )
            );

            return;
        }

        /*
         * Chỉ xóa sau khi bank nhận tiền.
         */
        if (!deleteSaving(playerId)) {

            plugin.getLogger().severe(
                    "[kBank] CRITICAL: saving đã chuyển tiền "
                            + "nhưng không xóa được record. UUID="
                            + playerId
            );

            player.sendMessage(
                    ChatUtil.color(
                            "&cGiao dịch đã thực hiện nhưng "
                                    + "hệ thống gặp lỗi đồng bộ."
                    )
            );

            return;
        }

        player.sendMessage(
                ChatUtil.color(
                        "&a✔ Bạn đã rút tiết kiệm thành công!"
                )
        );

        player.sendMessage(
                ChatUtil.color(
                        "&7• Gốc: &f"
                                + ChatUtil.formatVND(
                                        saving.amount
                                )
        );

        player.sendMessage(
                ChatUtil.color(
                        "&7• Lãi: &a"
                                + ChatUtil.formatVND(
                                        interest
                                )
        );

        player.sendMessage(
                ChatUtil.color(
                        "&7• Tổng cộng nhận: &e"
                                + ChatUtil.formatVND(
                                        total
                                )
        );

        player.playSound(
                player.getLocation(),
                Sound.ENTITY_PLAYER_LEVELUP,
                1.0f,
                1.2f
        );
    }

    // =========================================================
    // SAVING INFO
    // =========================================================

    public void sendSavingInfo(Player player) {

        if (player == null) {
            return;
        }

        SavingData saving =
                getSaving(
                        player.getUniqueId()
                );

        if (saving == null) {

            player.sendMessage(
                    ChatUtil.color(
                            "&7Hiện bạn không có khoản tiết kiệm nào."
                    )
            );

            player.playSound(
                    player.getLocation(),
                    Sound.ENTITY_VILLAGER_NO,
                    1.0f,
                    1.0f
            );

            return;
        }

        double interest =
                saving.amount
                        * saving.rate
                        * saving.months;

        double total =
                saving.amount + interest;

        player.sendMessage(
                ChatUtil.color(
                        "&a📘 Thông tin tiết kiệm:"
                )
        );

        player.sendMessage(
                ChatUtil.color(
                        "&7• Gửi: &e"
                                + ChatUtil.formatVND(
                                        saving.amount
                                )
        );

        player.sendMessage(
                ChatUtil.color(
                        "&7• Kỳ hạn: &6"
                                + saving.months
                                + " tháng"
                )
        );

        player.sendMessage(
                ChatUtil.color(
                        "&7• Lãi suất: &a"
                                + formatRate(
                                        saving.rate
                                )
        );

        player.sendMessage(
                ChatUtil.color(
                        "&7• Ngày gửi: &b"
                                + ChatUtil.formatDates(
                                        saving.createdAt
                                )
        );

        player.sendMessage(
                ChatUtil.color(
                        "&7• Đến hạn: &b"
                                + ChatUtil.formatDates(
                                        saving.matureAt
                                )
        );

        player.sendMessage(
                ChatUtil.color(
                        "&7• Tiền lãi dự kiến: &a"
                                + ChatUtil.formatVND(
                                        interest
                                )
        );

        player.sendMessage(
                ChatUtil.color(
                        "&7• Dự kiến nhận: &e"
                                + ChatUtil.formatVND(
                                        total
                                )
        );

        player.playSound(
                player.getLocation(),
                Sound.UI_BUTTON_CLICK,
                1.0f,
                1.2f
        );
    }

    // =========================================================
    // EARLY WITHDRAW
    // =========================================================

    public synchronized void forceWithdraw(
            UUID playerId
    ) {

        if (playerId == null) {
            return;
        }

        Player player =
                Bukkit.getPlayer(playerId);

        if (player == null) {
            return;
        }

        SavingData saving =
                getSaving(playerId);

        if (saving == null) {

            player.sendMessage(
                    ChatUtil.color(
                            "&cBạn không có khoản tiết kiệm nào."
                    )
            );

            return;
        }

        /*
         * Rút sớm chỉ nhận gốc.
         */
        boolean deposited =
                plugin.getBankManager()
                        .addMoney(
                                playerId,
                                saving.amount
                        );

        if (!deposited) {

            player.sendMessage(
                    ChatUtil.color(
                            "&cKhông thể hoàn tất rút tiết kiệm sớm."
                    )
            );

            return;
        }

        if (!deleteSaving(playerId)) {

            plugin.getLogger().severe(
                    "[kBank] CRITICAL: early saving withdrawal "
                            + "đã cộng tiền nhưng không xóa record. UUID="
                            + playerId
            );

            player.sendMessage(
                    ChatUtil.color(
                            "&cGiao dịch đã thực hiện nhưng "
                                    + "hệ thống gặp lỗi đồng bộ."
                    )
            );

            return;
        }

        player.sendMessage(
                ChatUtil.color(
                        "&e⚠ Bạn đã rút tiết kiệm sớm."
                )
        );

        player.sendMessage(
                ChatUtil.color(
                        "&7• Tiền gốc nhận lại: &f"
                                + ChatUtil.formatVND(
                                        saving.amount
                                )
        );

        player.sendMessage(
                ChatUtil.color(
                        "&7• Không nhận lãi suất kỳ hạn."
                )
        );

        player.playSound(
                player.getLocation(),
                Sound.ENTITY_ITEM_BREAK,
                1.0f,
                1.2f
        );
    }

    // =========================================================
    // DELETE
    // =========================================================

    private boolean deleteSaving(UUID uuid) {

        if (uuid == null) {
            return false;
        }

        String sql = """
                DELETE FROM savings
                WHERE uuid = ?
                """;

        try (
                Connection connection =
                        plugin.getDatabase().getConnection();
                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            if (connection == null) {
                return false;
            }

            statement.setString(
                    1,
                    uuid.toString()
            );

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {

            plugin.getLogger().severe(
                    "[kBank] Không thể xóa saving "
                            + uuid
                            + ": "
                            + e.getMessage()
            );

            return false;
        }
    }

    // =========================================================
    // RATE
    // =========================================================

    private double getRate(int months) {

        String path =
                "interest-rates." + months;

        if (plugin.getConfig().contains(path)) {

            return plugin.getConfig()
                    .getDouble(path);
        }

        return plugin.getConfig()
                .getDouble(
                        "saving.rate",
                        0.01
                );
    }

    // =========================================================
    // VALID PERIOD
    // =========================================================

    private boolean isValidPeriod(int months) {

        return months == 3
                || months == 6
                || months == 12;
    }

    // =========================================================
    // FORMAT RATE
    // =========================================================

    private String formatRate(double rate) {

        return String.format(
                "%.2f%%/tháng",
                rate * 100.0
        );
    }
}