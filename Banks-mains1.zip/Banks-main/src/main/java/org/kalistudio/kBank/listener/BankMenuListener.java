// =========================================================
// SAVING PERIOD MENU
// =========================================================

if (e.getView().getTitle()
        .equals(
                ChatUtil.color(
                        "&dChọn thời hạn tiết kiệm"
                )
        )) {

    e.setCancelled(true);

    if (!(e.getWhoClicked() instanceof Player player)) {
        return;
    }

    ItemStack clicked =
            e.getCurrentItem();

    if (clicked == null
            || !clicked.hasItemMeta()) {
        return;
    }

    ItemMeta meta =
            clicked.getItemMeta();

    if (meta == null
            || !meta.hasCustomModelData()) {
        return;
    }

    int months =
            meta.getCustomModelData();

    player.closeInventory();

    plugin.getSavingManager()
            .setSelectingPeriod(
                    player.getUniqueId(),
                    false
            );

    plugin.getGuiManager()
            .openAnvilInput(
                    player,
                    "Nhập số tiền gửi ("
                            + months
                            + " tháng)",
                    amount ->
                            processSavingDeposit(
                                    player,
                                    amount,
                                    months
                            )
            );

    return;
}


// =========================================================
// SAVING ADDITIONAL DEPOSIT
// =========================================================

if (e.getView().getTitle()
        .equals(
                ChatUtil.color(
                        "&dChọn kỳ hạn gửi thêm"
                )
        )) {

    e.setCancelled(true);

    if (!(e.getWhoClicked() instanceof Player player)) {
        return;
    }

    ItemStack clicked =
            e.getCurrentItem();

    if (clicked == null
            || !clicked.hasItemMeta()) {
        return;
    }

    ItemMeta meta =
            clicked.getItemMeta();

    if (meta == null
            || !meta.hasCustomModelData()) {
        return;
    }

    int months =
            meta.getCustomModelData();

    player.closeInventory();

    plugin.getSavingManager()
            .setSelectingPeriod(
                    player.getUniqueId(),
                    false
            );

    plugin.getGuiManager()
            .openAnvilInput(
                    player,
                    "Nhập số tiền gửi thêm ("
                            + months
                            + " tháng)",
                    amount ->
                            processSavingDeposit(
                                    player,
                                    amount,
                                    months
                            )
            );

    return;
}

Sau đó thêm method này vào cuối "BankMenuListener":

// =========================================================
// SAVING TRANSACTION
// =========================================================

private void processSavingDeposit(
        Player player,
        double amount,
        int months
) {

    if (player == null) {
        return;
    }

    if (!Double.isFinite(amount)
            || amount <= 0) {

        player.sendMessage(
                ChatUtil.color(
                        "&cSố tiền phải lớn hơn 0."
                )
        );

        player.playSound(
                player.getLocation(),
                Sound.ENTITY_VILLAGER_NO,
                1.0f,
                1.0f
        );

        return;
    }

    if (months != 3
            && months != 6
            && months != 12) {

        player.sendMessage(
                ChatUtil.color(
                        "&cKỳ hạn tiết kiệm không hợp lệ."
                )
        );

        return;
    }

    UUID uuid =
            player.getUniqueId();

    /*
     * =============================================
     * 1. ĐỌC SỐ DƯ
     * =============================================
     */

    double bankBalance =
            plugin.getBankManager()
                    .getMoney(uuid);

    double vaultBalance =
            plugin.getEconomy()
                    .getBalance(player);

    double totalBalance =
            bankBalance + vaultBalance;

    if (amount > totalBalance) {

        player.sendMessage(
                ChatUtil.color(
                        "&cBạn không đủ tiền để tiết kiệm "
                                + "&e"
                                + ChatUtil.formatVND(
                                        amount
                                )
                                + "&c."
                )
        );

        player.playSound(
                player.getLocation(),
                Sound.ENTITY_VILLAGER_NO,
                1.0f,
                1.0f
        );

        return;
    }

    /*
     * =============================================
     * 2. TÍNH PHẦN LẤY TỪ BANK / VAULT
     * =============================================
     *
     * Ưu tiên dùng tiền trong BANK trước.
     */

    double fromBank =
            Math.min(
                    bankBalance,
                    amount
            );

    double fromVault =
            amount - fromBank;

    boolean bankRemoved = false;
    boolean vaultRemoved = false;

    /*
     * =============================================
     * 3. TRỪ BANK
     * =============================================
     */

    if (fromBank > 0) {

        bankRemoved =
                plugin.getBankManager()
                        .removeMoney(
                                uuid,
                                fromBank
                        );

        if (!bankRemoved) {

            player.sendMessage(
                    ChatUtil.color(
                            "&cKhông thể trừ tiền từ tài khoản ngân hàng."
                    )
            );

            player.playSound(
                    player.getLocation(),
                    Sound.BLOCK_NOTE_BLOCK_BASS,
                    1.0f,
                    0.7f
            );

            return;
        }
    }

    /*
     * =============================================
     * 4. TRỪ VAULT
     * =============================================
     */

    if (fromVault > 0) {

        if (plugin.getEconomy() == null) {

            if (bankRemoved) {

                plugin.getBankManager()
                        .addMoney(
                                uuid,
                                fromBank
                        );
            }

            player.sendMessage(
                    ChatUtil.color(
                            "&cHệ thống economy hiện không khả dụng."
                    )
            );

            return;
        }

        var response =
                plugin.getEconomy()
                        .withdrawPlayer(
                                player,
                                fromVault
                        );

        if (!response.transactionSuccess()) {

            /*
             * Vault fail -> rollback BANK.
             */

            if (bankRemoved) {

                plugin.getBankManager()
                        .addMoney(
                                uuid,
                                fromBank
                        );
            }

            player.sendMessage(
                    ChatUtil.color(
                            "&cKhông thể trừ tiền từ tài khoản của bạn."
                    )
            );

            player.playSound(
                    player.getLocation(),
                    Sound.BLOCK_NOTE_BLOCK_BASS,
                    1.0f,
                    0.7f
            );

            return;
        }

        vaultRemoved = true;
    }

    /*
     * =============================================
     * 5. LƯU SAVING
     * =============================================
     */

    boolean saved =
            plugin.getSavingManager()
                    .saveDeposit(
                            uuid,
                            amount,
                            months
                    );

    if (!saved) {

        /*
         * =========================================
         * SAVE FAIL -> ROLLBACK TOÀN BỘ
         * =========================================
         */

        if (bankRemoved) {

            plugin.getBankManager()
                    .addMoney(
                            uuid,
                            fromBank
                    );
        }

        if (vaultRemoved) {

            plugin.getEconomy()
                    .depositPlayer(
                            player,
                            fromVault
                    );
        }

        plugin.getLogger().severe(
                "[kBank] Saving transaction failed. "
                        + "Rollback UUID="
                        + uuid
        );

        player.sendMessage(
                ChatUtil.color(
                        "&cKhông thể tạo khoản tiết kiệm."
                )
        );

        player.sendMessage(
                ChatUtil.color(
                        "&7Tiền của bạn đã được hoàn lại."
                )
        );

        player.playSound(
                player.getLocation(),
                Sound.BLOCK_NOTE_BLOCK_BASS,
                1.0f,
                0.7f
        );

        return;
    }

    /*
     * =============================================
     * 6. THÀNH CÔNG
     * =============================================
     */

    player.sendMessage(
            ChatUtil.color(
                    "&a✔ Gửi tiết kiệm thành công!"
            )
    );

    player.sendMessage(
            ChatUtil.color(
                    "&7• Số tiền: &e"
                            + ChatUtil.formatVND(
                                    amount
                            )
            )
    );

    player.sendMessage(
            ChatUtil.color(
                    "&7• Kỳ hạn: &6"
                            + months
                            + " tháng"
            )
    );

    player.sendMessage(
            ChatUtil.color(
                    "&7• Nguồn tiền: "
                            + (
                            fromBank > 0
                                    ? "&bNgân hàng"
                                    : ""
                    )
                            + (
                            fromBank > 0
                                    && fromVault > 0
                                    ? " &7+ "
                                    : ""
                    )
                            + (
                            fromVault > 0
                                    ? "&aVí"
                                    : ""
                    )
            )
    );

    player.playSound(
            player.getLocation(),
            Sound.ENTITY_EXPERIENCE_ORB_PICKUP,
            1.0f,
            1.2f
    );
}