package org.kalistudio.kBank.api;
public interface PrivateBankCoreAPI {
    PrivateBankService getPrivateBankService();
}
