package org.kalistudio.kBank.banking.debt;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.kalistudio.kBank.KBank;
import org.kalistudio.kBank.api.DebtService;
import org.kalistudio.kBank.api.event.DebtCreatedEvent;
import org.kalistudio.kBank.api.event.DebtStatusChangedEvent;
import org.kalistudio.kBank.api.model.DebtSnapshot;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.*;
import java.util.UUID;

/**
 * Craftopia Bank - Debt Core
 *
 * Hệ thống nợ dùng chung cho:
 *
 * - Server Bank
 * - Private Bank
 * - Owner Bankruptcy Debt
 *
 * DebtCore KHÔNG quản lý:
 *
 * - Tạo Private Bank
 * - Owner Private Bank
 * - Reputation
 * - Rating
 * - Bankruptcy
 * - Chính sách lãi Private Bank
 *
 * PrivateBankCore chỉ giao tiếp với DebtCore thông qua API public.
 */
public class DebtCore implements DebtService {

    private final KBank plugin;
    private final Economy economy;

    private static final int MONEY_SCALE = 2;
    private static final long DAY_MILLIS = 24L * 60L * 60L * 1000L;

    private static final String TABLE = "kbank_debts";
    private static final String NEGATIVE_TABLE = "kbank_negative_balance";

    public DebtCore(KBank plugin) {
        this.plugin = plugin;
        this.economy = plugin.getEconomy();

        createTables();
        startProcessor();

        plugin.getLogger().info("[DebtCore] Debt Core đã khởi động.");
    }

    // =========================================================
    // DATABASE
    // =========================================================

    private Connection getConnection() throws SQLException {
        return plugin.getBankManager().getConnection();
    }

    private void createTables() {

        String debtSql = """
                CREATE TABLE IF NOT EXISTS kbank_debts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,

                    debtor_uuid TEXT NOT NULL,

                    original_amount DOUBLE NOT NULL,
                    remaining_amount DOUBLE NOT NULL,

                    type TEXT NOT NULL,
                    status TEXT NOT NULL,

                    owner_type TEXT NOT NULL DEFAULT 'SERVER_BANK',
                    owner_id TEXT,

                    created_at BIGINT NOT NULL,

                    grace_uses INTEGER NOT NULL DEFAULT 0,

                    bad_debt_since BIGINT NOT NULL DEFAULT 0,

                    current_obligation_day BIGINT NOT NULL DEFAULT 0,
                    current_day_paid DOUBLE NOT NULL DEFAULT 0,

                    last_payment_at BIGINT NOT NULL DEFAULT 0,
                    last_enforcement_at BIGINT NOT NULL DEFAULT 0
                )
                """;

        String negativeSql = """
                CREATE TABLE IF NOT EXISTS kbank_negative_balance (
                    uuid TEXT PRIMARY KEY,
                    amount DOUBLE NOT NULL DEFAULT 0
                )
                """;

        try (Connection connection = getConnection();
             Statement statement = connection.createStatement()) {

            statement.executeUpdate(debtSql);
            statement.executeUpdate(negativeSql);

            statement.executeUpdate("""
                    CREATE INDEX IF NOT EXISTS
                    idx_kbank_debts_player
                    ON kbank_debts(debtor_uuid)
                    """);

            statement.executeUpdate("""
                    CREATE INDEX IF NOT EXISTS
                    idx_kbank_debts_status
                    ON kbank_debts(status)
                    """);

        } catch (SQLException e) {
            plugin.getLogger().severe(
                    "[DebtCore] Không thể tạo database table."
            );
            e.printStackTrace();
        }
    }

    // =========================================================
    // CREATE DEBT
    // =========================================================

    /**
     * Tạo debt mặc định thuộc Server Bank.
     */
    @Override
    public DebtSnapshot createDebt(
            UUID player,
            BigDecimal amount
    ) {
        return createDebt(
                player,
                amount,
                DebtType.SERVER_LOAN,
                "SERVER_BANK",
                null
        );
    }

    /**
     * API chung cho PrivateBankCore.
     *
     * Ví dụ:
     *
     * PRIVATE_BANK_LOAN
     * OWNER_BANKRUPTCY_DEBT
     */
    public DebtSnapshot createDebt(
            UUID player,
            BigDecimal amount,
            DebtType type,
            String ownerType,
            String ownerId
    ) {

        if (player == null ||
                amount == null ||
                type == null ||
                ownerType == null) {

            return null;
        }

        amount = money(amount);

        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            return null;
        }

        long now = System.currentTimeMillis();

        String sql = """
                INSERT INTO kbank_debts (
                    debtor_uuid,
                    original_amount,
                    remaining_amount,
                    type,
                    status,
                    owner_type,
                    owner_id,
                    created_at,
                    grace_uses,
                    bad_debt_since,
                    current_obligation_day,
                    current_day_paid,
                    last_payment_at,
                    last_enforcement_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, 0, 0, 0)
                """;

        try (Connection connection = getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(
                             sql,
                             Statement.RETURN_GENERATED_KEYS
                     )) {

            statement.setString(1, player.toString());
            statement.setDouble(2, amount.doubleValue());
            statement.setDouble(3, amount.doubleValue());
            statement.setString(4, type.name());
            statement.setString(5, DebtStatus.GRACE.name());
            statement.setString(6, ownerType);
            statement.setString(7, ownerId);
            statement.setLong(8, now);

            statement.executeUpdate();

            DebtSnapshot snapshot = getDebt(player);

            if (snapshot != null) {
                Bukkit.getPluginManager().callEvent(
                        new DebtCreatedEvent(snapshot)
                );
            }

            return snapshot;

        } catch (SQLException e) {
            plugin.getLogger().severe(
                    "[DebtCore] Không thể tạo khoản nợ cho "
                            + player
            );
            e.printStackTrace();
        }

        return null;
    }

    // =========================================================
    // GET DEBT
    // =========================================================

    @Override
    public DebtSnapshot getDebt(UUID player) {

        if (player == null) {
            return null;
        }

        String sql = """
                SELECT *
                FROM kbank_debts
                WHERE debtor_uuid = ?
                  AND status <> ?
                ORDER BY id ASC
                LIMIT 1
                """;

        try (Connection connection = getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setString(1, player.toString());
            statement.setString(2, DebtStatus.PAID.name());

            try (ResultSet result = statement.executeQuery()) {

                if (!result.next()) {
                    return null;
                }

                return createSnapshot(result);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * Lấy debt theo ID.
     *
     * API này dành cho PrivateBankCore.
     */
    public DebtSnapshot getDebt(long debtId) {

        String sql = """
                SELECT *
                FROM kbank_debts
                WHERE id = ?
                """;

        try (Connection connection = getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setLong(1, debtId);

            try (ResultSet result = statement.executeQuery()) {

                if (!result.next()) {
                    return null;
                }

                return createSnapshot(result);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    private DebtSnapshot createSnapshot(
            ResultSet result
    ) throws SQLException {

        return new DebtSnapshot(
                UUID.fromString(
                        result.getString("debtor_uuid")
                ),
                money(
                        result.getDouble("remaining_amount")
                ),
                DebtStatus.valueOf(
                        result.getString("status")
                ),
                DebtType.valueOf(
                        result.getString("type")
                ),
                result.getInt("grace_uses"),
                result.getLong("created_at"),
                result.getLong("bad_debt_since")
        );
    }

    // =========================================================
    // REPAYMENT
    // =========================================================

    @Override
    public boolean repay(
            UUID player,
            BigDecimal amount
    ) {

        if (player == null ||
                amount == null ||
                amount.compareTo(BigDecimal.ZERO) <= 0) {

            return false;
        }

        DebtRecord debt = findActiveDebt(player);

        if (debt == null) {
            return false;
        }

        amount = money(amount);

        BigDecimal actualPayment =
                amount.min(debt.remainingAmount);

        if (actualPayment.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }

        /*
         * Nếu player đang có số dư âm:
         *
         * tiền trả nợ không được lấy từ negative balance.
         *
         * Player phải thực sự có tiền.
         */
        if (!withdrawPlayer(player, actualPayment)) {
            return false;
        }

        long now = System.currentTimeMillis();

        BigDecimal remaining =
                money(
                        debt.remainingAmount
                                .subtract(actualPayment)
                );

        long obligationDay =
                calculateObligationDay(
                        debt.createdAt,
                        now
                );

        double newDayPaid =
                debt.currentDayPaid
                        + actualPayment.doubleValue();

        DebtStatus newStatus =
                remaining.compareTo(BigDecimal.ZERO) <= 0
                        ? DebtStatus.PAID
                        : DebtStatus.CURRENT;

        String sql = """
                UPDATE kbank_debts
                SET remaining_amount = ?,
                    status = ?,
                    current_obligation_day = ?,
                    current_day_paid = ?,
                    last_payment_at = ?
                WHERE id = ?
                """;

        try (Connection connection = getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setDouble(
                    1,
                    remaining.doubleValue()
            );

            statement.setString(
                    2,
                    newStatus.name()
            );

            statement.setLong(
                    3,
                    obligationDay
            );

            statement.setDouble(
                    4,
                    newDayPaid
            );

            statement.setLong(
                    5,
                    now
            );

            statement.setLong(
                    6,
                    debt.id
            );

            statement.executeUpdate();

            DebtSnapshot snapshot =
                    getDebt(player);

            if (snapshot != null &&
                    newStatus != debt.status) {

                Bukkit.getPluginManager().callEvent(
                        new DebtStatusChangedEvent(snapshot)
                );
            }

            return true;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        /*
         * Nếu database update thất bại sau khi đã rút tiền,
         * cố gắng hoàn lại tiền cho player.
         */
        depositPlayer(player, actualPayment);

        return false;
    }

    // =========================================================
    // DAILY DEBT PROCESSOR
    // =========================================================

    private void startProcessor() {

        /*
         * Kiểm tra mỗi 30 phút.
         *
         * Không dùng bộ đếm RAM.
         * Mọi mốc thời gian đều lưu database nên server
         * restart không làm mất trạng thái.
         */
        long period =
                20L * 60L * 30L;

        Bukkit.getScheduler().runTaskTimer(
                plugin,
                this::processAllDebts,
                20L * 60L,
                period
        );
    }

    private void processAllDebts() {

        String sql = """
                SELECT *
                FROM kbank_debts
                WHERE status <> ?
                """;

        try (Connection connection = getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setString(
                    1,
                    DebtStatus.PAID.name()
            );

            try (ResultSet result =
                         statement.executeQuery()) {

                while (result.next()) {

                    DebtRecord debt =
                            readDebt(result);

                    processDebt(debt);
                }
            }

        } catch (SQLException e) {
            plugin.getLogger().warning(
                    "[DebtCore] Không thể xử lý debt."
            );
            e.printStackTrace();
        }
    }

    private void processDebt(
            DebtRecord debt
    ) {

        long now = System.currentTimeMillis();

        long obligationDay =
                calculateObligationDay(
                        debt.createdAt,
                        now
                );

        /*
         * 3 ngày đầu:
         *
         * DAY 0
         * DAY 1
         * DAY 2
         *
         * Từ DAY 3 trở đi là nghĩa vụ đầu tiên.
         *
         * Theo thời gian thực:
         * 0-24h = ngày 1
         * 24-48h = ngày 2
         * 48-72h = ngày 3
         * >=72h = ngày 4 / bắt đầu nghĩa vụ
         */
        if (now <
                debt.createdAt
                        + DebtPolicy.GRACE_DAYS * DAY_MILLIS) {

            if (debt.status != DebtStatus.GRACE) {
                changeStatus(
                        debt,
                        DebtStatus.GRACE
                );
            }

            return;
        }

        BigDecimal minimumPayment =
                calculateMinimumPayment(
                        debt.remainingAmount
                );

        /*
         * Nếu đã hoàn thành nghĩa vụ hôm nay:
         * chuyển sang ngày tiếp theo.
         */
        if (debt.currentObligationDay <
                obligationDay) {

            debt.currentObligationDay =
                    obligationDay;

            debt.currentDayPaid = 0;

            updateDailyCounter(
                    debt.id,
                    obligationDay,
                    0
            );
        }

        /*
         * Đã trả đủ >=10% hôm nay.
         */
        if (money(
                BigDecimal.valueOf(
                        debt.currentDayPaid
                )
        ).compareTo(minimumPayment) >= 0) {

            if (debt.status == DebtStatus.BAD_DEBT) {
                /*
                 * Không tự xóa nợ xấu chỉ vì trả tiền.
                 * Bad debt chỉ kết thúc khi khoản nợ được xử lý
                 * hoặc còn lại 0.
                 */
                return;
            }

            if (debt.status != DebtStatus.CURRENT) {
                changeStatus(
                        debt,
                        DebtStatus.CURRENT
                );
            }

            return;
        }

        /*
         * Chưa đủ nghĩa vụ.
         *
         * Không tự động rút tiền.
         *
         * Đây là nghĩa vụ mà player phải tự trả.
         */
        handleMissedObligation(
                debt,
                minimumPayment
        );
    }

    // =========================================================
    // MISSED PAYMENT
    // =========================================================

    private void handleMissedObligation(
            DebtRecord debt,
            BigDecimal minimumPayment
    ) {

        /*
         * Tránh tăng graceUses nhiều lần trong cùng
         * một ngày do scheduler chạy mỗi 30 phút.
         */
        long currentDay =
                debt.currentObligationDay;

        if (debt.status == DebtStatus.BAD_DEBT) {
            processBadDebt(debt);
            return;
        }

        /*
         * Nếu đã sử dụng grace cho ngày này thì không dùng lại.
         *
         * grace_uses chỉ tăng khi chuyển sang một
         * ngày nghĩa vụ mới.
         */
        if (debt.lastGraceObligationDay ==
                currentDay) {

            return;
        }

        /*
         * Còn lượt ân nợ.
         */
        if (debt.graceUses <
                DebtPolicy.GRACE_USES) {

            int newUses =
                    debt.graceUses + 1;

            markGraceUsed(
                    debt.id,
                    newUses,
                    currentDay
            );

            notify(
                    debt.player,
                    message(
                            "debt.grace-used",
                            "%remaining%",
                            String.valueOf(
                                    DebtPolicy.GRACE_USES
                                            - newUses
                            )
                    )
            );

            return;
        }

        /*
         * Hết 2 lần ân nợ.
         */
        markBadDebt(debt);
    }

    // =========================================================
    // BAD DEBT
    // =========================================================

    private void markBadDebt(
            DebtRecord debt
    ) {

        long now =
                System.currentTimeMillis();

        String sql = """
                UPDATE kbank_debts
                SET status = ?,
                    bad_debt_since = ?
                WHERE id = ?
                AND status <> ?
                """;

        try (Connection connection = getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setString(
                    1,
                    DebtStatus.BAD_DEBT.name()
            );

            statement.setLong(
                    2,
                    now
            );

            statement.setLong(
                    3,
                    debt.id
            );

            statement.setString(
                    4,
                    DebtStatus.PAID.name()
            );

            if (statement.executeUpdate() > 0) {

                debt.status =
                        DebtStatus.BAD_DEBT;

                debt.badDebtSince =
                        now;

                DebtSnapshot snapshot =
                        getDebt(debt.id);

                if (snapshot != null) {
                    Bukkit.getPluginManager()
                            .callEvent(
                                    new DebtStatusChangedEvent(
                                            snapshot
                                    )
                            );
                }

                notify(
                        debt.player,
                        message(
                                "debt.bad-debt",
                                null,
                                null
                        )
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void processBadDebt(
            DebtRecord debt
    ) {

        if (debt.badDebtSince <= 0) {
            return;
        }

        long elapsed =
                System.currentTimeMillis()
                        - debt.badDebtSince;

        long days =
                elapsed / DAY_MILLIS;

        /*
         * "quá 3 ngày" => phải vượt qua 3 ngày.
         */
        if (days <=
                DebtPolicy.BAD_DEBT_DAYS_BEFORE_ENFORCEMENT) {

            return;
        }

        /*
         * Không cưỡng chế lại cùng một khoản nợ
         * sau khi đã enforcement.
         */
        if (debt.lastEnforcementAt > 0) {
            return;
        }

        executeEnforcement(debt);
    }

    // =========================================================
    // ENFORCEMENT
    // =========================================================

    private void executeEnforcement(
            DebtRecord debt
    ) {

        BigDecimal enforcementAmount =
                percentage(
                        debt.remainingAmount,
                        DebtPolicy.ENFORCEMENT_PERCENT
                );

        if (enforcementAmount
                .compareTo(BigDecimal.ZERO) <= 0) {

            return;
        }

        Player player =
                Bukkit.getPlayer(debt.player);

        BigDecimal available =
                BigDecimal.ZERO;

        if (player != null &&
                player.isOnline()) {

            available =
                    money(
                            BigDecimal.valueOf(
                                    economy.getBalance(player)
                            )
                    );
        }

        BigDecimal actual =
                available.min(
                        enforcementAmount
                );

        BigDecimal missing =
                enforcementAmount.subtract(actual);

        /*
         * Trừ tiền player nếu có.
         */
        if (actual.compareTo(BigDecimal.ZERO) > 0 &&
                player != null &&
                player.isOnline()) {

            economy.withdrawPlayer(
                    player,
                    actual.doubleValue()
            );
        }

        /*
         * Phần thiếu chuyển thành negative balance.
         */
        if (missing.compareTo(BigDecimal.ZERO) > 0) {

            addNegativeBalance(
                    debt.player,
                    missing
            );
        }

        BigDecimal remaining =
                money(
                        debt.remainingAmount
                                .subtract(
                                        enforcementAmount
                                )
                );

        long now =
                System.currentTimeMillis();

        DebtStatus newStatus =
                remaining.compareTo(
                        BigDecimal.ZERO
                ) <= 0
                        ? DebtStatus.PAID
                        : DebtStatus.ENFORCED;

        String sql = """
                UPDATE kbank_debts
                SET remaining_amount = ?,
                    status = ?,
                    last_enforcement_at = ?,
                    last_payment_at = ?
                WHERE id = ?
                """;

        try (Connection connection = getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setDouble(
                    1,
                    remaining.doubleValue()
            );

            statement.setString(
                    2,
                    newStatus.name()
            );

            statement.setLong(
                    3,
                    now
            );

            statement.setLong(
                    4,
                    now
            );

            statement.setLong(
                    5,
                    debt.id
            );

            statement.executeUpdate();

            /*
             * Tiền actual đã được trừ từ player.
             *
             * Việc credit tiền về ngân hàng sở hữu khoản nợ
             * sẽ do BankingCore/PrivateBankCore gọi thông qua
             * owner information.
             *
             * DebtCore KHÔNG truy cập PrivateBankCore.
             */

            DebtSnapshot snapshot =
                    getDebt(debt.id);

            if (snapshot != null) {
                Bukkit.getPluginManager()
                        .callEvent(
                                new DebtStatusChangedEvent(
                                        snapshot
                                )
                        );
            }

            if (missing.compareTo(BigDecimal.ZERO) > 0) {

                notify(
                        debt.player,
                        message(
                                "debt.enforcement-failed",
                                null,
                                null
                        )
                );

                notify(
                        debt.player,
                        message(
                                "debt.negative-amount",
                                "%amount%",
                                format(
                                        getNegativeBalance(
                                                debt.player
                                        )
                                )
                        )
                );

            } else {

                notify(
                        debt.player,
                        message(
                                "debt.enforced",
                                "%amount%",
                                format(
                                        enforcementAmount
                                )
                        )
                );
            }

        } catch (SQLException e) {
            /*
             * Nếu DB thất bại sau khi trừ tiền,
             * hoàn tiền lại cho player.
             */
            if (actual.compareTo(BigDecimal.ZERO) > 0 &&
                    player != null &&
                    player.isOnline()) {

                economy.depositPlayer(
                        player,
                        actual.doubleValue()
                );
            }

            e.printStackTrace();
        }
    }

    // =========================================================
    // DEBT TRANSFER
    // =========================================================

    /**
     * Chuyển khoản nợ từ Private Bank sang Server Bank.
     *
     * Số nợ KHÔNG được thay đổi.
     */
    public boolean transferDebt(
            long debtId,
            String newOwnerType,
            String newOwnerId
    ) {

        if (newOwnerType == null) {
            return false;
        }

        String sql = """
                UPDATE kbank_debts
                SET owner_type = ?,
                    owner_id = ?
                WHERE id = ?
                AND status <> ?
                """;

        try (Connection connection = getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setString(
                    1,
                    newOwnerType
            );

            statement.setString(
                    2,
                    newOwnerId
            );

            statement.setLong(
                    3,
                    debtId
            );

            statement.setString(
                    4,
                    DebtStatus.PAID.name()
            );

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Thay đổi loại debt.
     *
     * Dành cho Owner 2 khi tạo/chuyển bankruptcy debt.
     */
    public boolean setDebtType(
            long debtId,
            DebtType type
    ) {

        if (type == null) {
            return false;
        }

        try (Connection connection = getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(
                             """
                             UPDATE kbank_debts
                             SET type=?
                             WHERE id=?
                             """
                     )) {

            statement.setString(
                    1,
                    type.name()
            );

            statement.setLong(
                    2,
                    debtId
            );

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Lấy owner của khoản nợ.
     *
     * Format:
     * [ownerType, ownerId]
     */
    public String[] getDebtOwner(
            long debtId
    ) {

        try (Connection connection = getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(
                             """
                             SELECT owner_type, owner_id
                             FROM kbank_debts
                             WHERE id=?
                             """
                     )) {

            statement.setLong(
                    1,
                    debtId
            );

            try (ResultSet result =
                         statement.executeQuery()) {

                if (!result.next()) {
                    return null;
                }

                return new String[]{
                        result.getString("owner_type"),
                        result.getString("owner_id")
                };
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    // =========================================================
    // NEGATIVE BALANCE
    // =========================================================

    /**
     * Lấy số dư âm.
     */
    public BigDecimal getNegativeBalance(
            UUID player
    ) {

        try (Connection connection = getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(
                             """
                             SELECT amount
                             FROM kbank_negative_balance
                             WHERE uuid=?
                             """
                     )) {

            statement.setString(
                    1,
                    player.toString()
            );

            try (ResultSet result =
                         statement.executeQuery()) {

                if (!result.next()) {
                    return BigDecimal.ZERO;
                }

                return money(
                        result.getDouble("amount")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return BigDecimal.ZERO;
    }

    private void addNegativeBalance(
            UUID player,
            BigDecimal amount
    ) {

        if (!negativeBalanceEnabled()) {
            return;
        }

        amount = money(amount);

        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            return;
        }

        String sql = """
                INSERT INTO kbank_negative_balance (
                    uuid,
                    amount
                )
                VALUES (?, ?)
                ON CONFLICT(uuid)
                DO UPDATE SET
                    amount =
                        kbank_negative_balance.amount
                        + excluded.amount
                """;

        try (Connection connection = getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setString(
                    1,
                    player.toString()
            );

            statement.setDouble(
                    2,
                    amount.doubleValue()
            );

            statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * API rất quan trọng cho BankingCore.
     *
     * Khi player kiếm được tiền:
     *
     * tiền mới -> trả negative balance trước
     * phần còn lại -> player thực nhận.
     *
     * Ví dụ:
     *
     * negative = -500
     * player kiếm 800
     *
     * -> 500 trả negative
     * -> player nhận 300
     */
    public BigDecimal processIncomingMoney(
            UUID player,
            BigDecimal amount
    ) {

        if (!negativeBalanceEnabled() ||
                !autoRepayNegativeBalance()) {

            return money(amount);
        }

        amount = money(amount);

        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }

        BigDecimal negative =
                getNegativeBalance(player);

        if (negative.compareTo(BigDecimal.ZERO) <= 0) {
            return amount;
        }

        BigDecimal repayment =
                amount.min(negative);

        BigDecimal remaining =
                money(
                        negative.subtract(repayment)
                );

        try (Connection connection = getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(
                             """
                             UPDATE kbank_negative_balance
                             SET amount=?
                             WHERE uuid=?
                             """
                     )) {

            statement.setDouble(
                    1,
                    remaining.doubleValue()
            );

            statement.setString(
                    2,
                    player.toString()
            );

            statement.executeUpdate();

            notify(
                    player,
                    message(
                            "debt.negative-repaid",
                            "%amount%",
                            format(repayment)
                    )
            );

            return money(
                    amount.subtract(repayment)
            );

        } catch (SQLException e) {
            e.printStackTrace();
        }

        /*
         * Nếu database lỗi thì không được làm mất tiền.
         * Trả lại toàn bộ amount cho caller xử lý.
         */
        return amount;
    }

    /**
     * Số dư âm không được sử dụng.
     */
    public boolean canUseBalance(
            UUID player
    ) {

        if (!negativeBalanceEnabled()) {
            return true;
        }

        return getNegativeBalance(player)
                .compareTo(BigDecimal.ZERO) <= 0;
    }

    // =========================================================
    // RESTRICTION API
    // =========================================================

    /**
     * Player có đang bị hạn chế do nợ xấu hay không.
     *
     * RestrictionManager sau này sẽ gọi API này để chặn:
     *
     * /shop
     * /trade
     * /pay
     */
    public boolean hasBadDebt(
            UUID player
    ) {

        String sql = """
                SELECT 1
                FROM kbank_debts
                WHERE debtor_uuid=?
                AND status=?
                LIMIT 1
                """;

        try (Connection connection = getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setString(
                    1,
                    player.toString()
            );

            statement.setString(
                    2,
                    DebtStatus.BAD_DEBT.name()
            );

            try (ResultSet result =
                         statement.executeQuery()) {

                return result.next();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean isShopBlocked(UUID player) {

        return hasBadDebt(player)
                && plugin.getConfig().getBoolean(
                "debt-restrictions.shop.blocked",
                true
        );
    }

    public boolean isTradeBlocked(UUID player) {

        return hasBadDebt(player)
                && plugin.getConfig().getBoolean(
                "debt-restrictions.trade.blocked",
                true
        );
    }

    public boolean isPayBlocked(UUID player) {

        return hasBadDebt(player)
                && plugin.getConfig().getBoolean(
                "debt-restrictions.pay.blocked",
                true
        );
    }

    // =========================================================
    // INTERNAL DATABASE
    // =========================================================

    private DebtRecord findActiveDebt(
            UUID player
    ) {

        String sql = """
                SELECT *
                FROM kbank_debts
                WHERE debtor_uuid=?
                AND status <> ?
                ORDER BY id ASC
                LIMIT 1
                """;

        try (Connection connection = getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setString(
                    1,
                    player.toString()
            );

            statement.setString(
                    2,
                    DebtStatus.PAID.name()
            );

            try (ResultSet result =
                         statement.executeQuery()) {

                if (!result.next()) {
                    return null;
                }

                return readDebt(result);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    private DebtRecord readDebt(
            ResultSet result
    ) throws SQLException {

        DebtRecord debt = new DebtRecord();

        debt.id =
                result.getLong("id");

        debt.player =
                UUID.fromString(
                        result.getString(
                                "debtor_uuid"
                        )
                );

        debt.originalAmount =
                money(
                        result.getDouble(
                                "original_amount"
                        )
                );

        debt.remainingAmount =
                money(
                        result.getDouble(
                                "remaining_amount"
                        )
                );

        debt.type =
                DebtType.valueOf(
                        result.getString("type")
                );

        debt.status =
                DebtStatus.valueOf(
                        result.getString("status")
                );

        debt.ownerType =
                result.getString("owner_type");

        debt.ownerId =
                result.getString("owner_id");

        debt.createdAt =
                result.getLong("created_at");

        debt.graceUses =
                result.getInt("grace_uses");

        debt.badDebtSince =
                result.getLong("bad_debt_since");

        debt.currentObligationDay =
                result.getLong(
                        "current_obligation_day"
                );

        debt.currentDayPaid =
                result.getDouble(
                        "current_day_paid"
                );

        debt.lastPaymentAt =
                result.getLong(
                        "last_payment_at"
                );

        debt.lastEnforcementAt =
                result.getLong(
                        "last_enforcement_at"
                );

        return debt;
    }

    private void changeStatus(
            DebtRecord debt,
            DebtStatus status
    ) {

        if (debt.status == status) {
            return;
        }

        try (Connection connection = getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(
                             """
                             UPDATE kbank_debts
                             SET status=?
                             WHERE id=?
                             """
                     )) {

            statement.setString(
                    1,
                    status.name()
            );

            statement.setLong(
                    2,
                    debt.id
            );

            statement.executeUpdate();

            debt.status = status;

            DebtSnapshot snapshot =
                    getDebt(debt.id);

            if (snapshot != null) {

                Bukkit.getPluginManager()
                        .callEvent(
                                new DebtStatusChangedEvent(
                                        snapshot
                                )
                        );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void markGraceUsed(
            long debtId,
            int graceUses,
            long obligationDay
    ) {

        String sql = """
                UPDATE kbank_debts
                SET grace_uses=?,
                    current_obligation_day=?,
                    current_day_paid=0
                WHERE id=?
                """;

        try (Connection connection = getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(
                    1,
                    graceUses
            );

            statement.setLong(
                    2,
                    obligationDay
            );

            statement.setLong(
                    3,
                    debtId
            );

            statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateDailyCounter(
            long debtId,
            long obligationDay,
            double paid
    ) {

        try (Connection connection = getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(
                             """
                             UPDATE kbank_debts
                             SET current_obligation_day=?,
                                 current_day_paid=?
                             WHERE id=?
                             """
                     )) {

            statement.setLong(
                    1,
                    obligationDay
            );

            statement.setDouble(
                    2,
                    paid
            );

            statement.setLong(
                    3,
                    debtId
            );

            statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // =========================================================
    // CALCULATIONS
    // =========================================================

    private long calculateObligationDay(
            long createdAt,
            long now
    ) {

        long elapsed =
                Math.max(
                        0,
                        now - createdAt
                );

        /*
         * 0 = grace
         * 1 = ngày nghĩa vụ đầu tiên sau grace
         * 2 = ngày nghĩa vụ thứ hai...
         */
        return Math.max(
                0,
                (elapsed / DAY_MILLIS)
                        - DebtPolicy.GRACE_DAYS
                        + 1
        );
    }

    private BigDecimal calculateMinimumPayment(
            BigDecimal remaining
    ) {

        return percentage(
                remaining,
                DebtPolicy.MIN_DAILY_PAYMENT_PERCENT
        );
    }

    private BigDecimal percentage(
            BigDecimal amount,
            BigDecimal percent
    ) {

        return money(
                amount
                        .multiply(percent)
                        .divide(
                                BigDecimal.valueOf(100),
                                MONEY_SCALE,
                                RoundingMode.HALF_UP
                        )
        );
    }

    // =========================================================
    // ECONOMY
    // =========================================================

    private boolean withdrawPlayer(
            UUID uuid,
            BigDecimal amount
    ) {

        Player player =
                Bukkit.getPlayer(uuid);

        if (player == null ||
                !player.isOnline()) {

            return false;
        }

        if (economy.getBalance(player)
                < amount.doubleValue()) {

            return false;
        }

        return economy.withdrawPlayer(
                player,
                amount.doubleValue()
        ).transactionSuccess();
    }

    private void depositPlayer(
            UUID uuid,
            BigDecimal amount
    ) {

        Player player =
                Bukkit.getPlayer(uuid);

        if (player == null ||
                !player.isOnline()) {

            return;
        }

        economy.depositPlayer(
                player,
                amount.doubleValue()
        );
    }

    // =========================================================
    // CONFIG
    // =========================================================

    private boolean negativeBalanceEnabled() {

        return plugin.getConfig().getBoolean(
                "negative-balance.enabled",
                true
        );
    }

    private boolean autoRepayNegativeBalance() {

        return plugin.getConfig().getBoolean(
                "negative-balance.priority-repayment",
                true
        );
    }

    // =========================================================
    // MESSAGE SERVICE COMPATIBILITY
    // =========================================================

    /**
     * Hiện source KBank đang load lang.yml thông qua getLang().
     *
     * DebtCore không tự tạo MessageService thứ hai.
     *
     * Khi MessageService chính được nối vào, method này có thể
     * chuyển sang MessageService mà không ảnh hưởng DebtCore API.
     */
    private String message(
            String path,
            String placeholder,
            String value
    ) {

        String prefix =
                plugin.getLang().getString(
                        "prefix",
                        "&6[&eBank&6] "
                );

        String message =
                plugin.getLang().getString(
                        path,
                        "&cKhông thể tải message: " + path
                );

        if (placeholder != null &&
                value != null) {

            message =
                    message.replace(
                            placeholder,
                            value
                    );
        }

        return color(prefix + message);
    }

    private String color(String text) {

        return org.bukkit.ChatColor
                .translateAlternateColorCodes(
                        '&',
                        text
                );
    }

    private void notify(
            UUID player,
            String message
    ) {

        Player target =
                Bukkit.getPlayer(player);

        if (target != null &&
                target.isOnline()) {

            target.sendMessage(message);
        }
    }

    // =========================================================
    // UTILS
    // =========================================================

    private BigDecimal money(
            BigDecimal value
    ) {

        return value.setScale(
                MONEY_SCALE,
                RoundingMode.HALF_UP
        );
    }

    private BigDecimal money(
            double value
    ) {

        return money(
                BigDecimal.valueOf(value)
        );
    }

    private String format(
            BigDecimal amount
    ) {

        return money(amount)
                .toPlainString();
    }

    // =========================================================
    // INTERNAL RECORD
    // =========================================================

    private static final class DebtRecord {

        private long id;

        private UUID player;

        private BigDecimal originalAmount;
        private BigDecimal remainingAmount;

        private DebtType type;
        private DebtStatus status;

        private String ownerType;
        private String ownerId;

        private long createdAt;

        private int graceUses;

        private long badDebtSince;

        private long currentObligationDay;
        private double currentDayPaid;

        private long lastPaymentAt;
        private long lastEnforcementAt;

        /*
         * Dùng để tránh scheduler 30 phút cộng grace nhiều lần
         * trong cùng một ngày.
         *
         * Giá trị được lưu bằng current_obligation_day.
         */
        private long lastGraceObligationDay = -1;
    }
}