package org.kalistudio.kBank.privatebank.deposit;
import java.math.BigDecimal;
import java.util.UUID;
public record PrivateDepositAccount(UUID player, String bankId, BigDecimal principal, long openedAt) {}
