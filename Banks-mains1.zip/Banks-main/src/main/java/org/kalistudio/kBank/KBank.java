package org.kalistudio.kBank;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import org.kalistudio.kBank.bank.BankManager;
import org.kalistudio.kBank.banking.transaction.TransactionService;
import org.kalistudio.kBank.command.AdminBankCommand;
import org.kalistudio.kBank.command.BankCommand;
import org.kalistudio.kBank.command.BankTabCompleter;
import org.kalistudio.kBank.command.TransferCommand;
import org.kalistudio.kBank.gui.GUIManager;
import org.kalistudio.kBank.listener.BankMenuListener;
import org.kalistudio.kBank.loan.DatabaseManager;
import org.kalistudio.kBank.loan.LoanManager;
import org.kalistudio.kBank.loan.SavingManager;
import org.kalistudio.kBank.papi.PapiExpansion;
import org.kalistudio.kBank.service.DailyInterestService;
import org.kalistudio.kBank.service.InterestService;

import java.io.File;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;

public class KBank extends JavaPlugin {

    private static KBank instance;

    // =========================================================
    // EXISTING SYSTEMS
    // =========================================================

    private BankManager bankManager;

    public BankManager getBankManager() {
        return bankManager;
    }

    private LoanManager loanManager;

    public LoanManager getLoanManager() {
        return loanManager;
    }

    private GUIManager guiManager;

    public GUIManager getGuiManager() {
        return guiManager;
    }

    private Economy economy;

    public Economy getEconomy() {
        return economy;
    }

    private SavingManager savingManager;

    public SavingManager getSavingManager() {
        return savingManager;
    }

    private DatabaseManager database;

    public DatabaseManager getDatabase() {
        return database;
    }

    // =========================================================
    // TRANSACTION CORE
    // =========================================================

    private TransactionService transactionService;

    public TransactionService getTransactionService() {
        return transactionService;
    }

    // =========================================================
    // INTEREST SYSTEM
    // =========================================================

    private InterestService interestService;

    public InterestService getInterestService() {
        return interestService;
    }

    private DailyInterestService dailyInterestService;

    public DailyInterestService getDailyInterestService() {
        return dailyInterestService;
    }

    // =========================================================
    // LANGUAGE
    // =========================================================

    private FileConfiguration lang;
    private File langFile;

    // =========================================================
    // INSTANCE
    // =========================================================

    public static KBank getInstance() {
        return instance;
    }

    // =========================================================
    // ENABLE
    // =========================================================

    @Override
    public void onEnable() {

        instance = this;

        // -----------------------------------------------------
        // DATA FOLDER
        // -----------------------------------------------------

        if (!getDataFolder().exists()) {
            getDataFolder().mkdirs();
        }

        // -----------------------------------------------------
        // CONFIG
        // -----------------------------------------------------

        saveDefaultConfig();
        reloadConfig();
        reloadLang();

        // =====================================================
        // VAULT
        // =====================================================

        if (getServer()
                .getPluginManager()
                .getPlugin("Vault") == null) {

            getLogger().severe(
                    "Vault không được cài!"
            );

            getServer()
                    .getPluginManager()
                    .disablePlugin(this);

            return;
        }

        if (getServer()
                .getServicesManager()
                .getRegistration(Economy.class) == null) {

            getLogger().severe(
                    "Không tìm thấy Economy provider của Vault!"
            );

            getServer()
                    .getPluginManager()
                    .disablePlugin(this);

            return;
        }

        economy = getServer()
                .getServicesManager()
                .getRegistration(Economy.class)
                .getProvider();

        if (economy == null) {

            getLogger().severe(
                    "Economy provider của Vault không tồn tại!"
            );

            getServer()
                    .getPluginManager()
                    .disablePlugin(this);

            return;
        }

        getLogger().info(
                "Economy provider: "
                        + economy.getName()
        );

        // =====================================================
        // DATABASE
        // =====================================================

        database = new DatabaseManager(this);

        // =====================================================
        // BANK CORE
        // =====================================================

        /*
         * BankManager phải được tạo trước InterestService
         * vì InterestService sử dụng BankManager.
         */
        bankManager = new BankManager(this);

        // =====================================================
        // EXISTING SYSTEMS
        // =====================================================

        loanManager = new LoanManager(this);

        savingManager = new SavingManager(this);

        // =====================================================
        // INTEREST SYSTEM
        // =====================================================

        try {

            /*
             * InterestService:
             *
             * - đọc lãi suất từ config
             * - tạo bảng bank_interest
             * - tính và trả lãi
             */
            interestService =
                    new InterestService(this);

            /*
             * DailyInterestService:
             *
             * - kiểm tra player online
             * - chạy mỗi 1 giờ
             * - gọi InterestService.applyInterest()
             */
            dailyInterestService =
                    new DailyInterestService(
                            this,
                            interestService
                    );

            dailyInterestService.start();

            getLogger().info(
                    "InterestService đã được khởi tạo."
            );

            getLogger().info(
                    "DailyInterestService đã được khởi động."
            );

        } catch (Exception e) {

            getLogger().severe(
                    "Không thể khởi tạo hệ thống lãi!"
            );

            e.printStackTrace();

            getServer()
                    .getPluginManager()
                    .disablePlugin(this);

            return;
        }

        // =====================================================
        // TRANSACTION CORE
        // =====================================================

        try {

            transactionService =
                    new TransactionService(this);

            getLogger().info(
                    "TransactionService đã được khởi tạo."
            );

        } catch (Exception e) {

            getLogger().severe(
                    "Không thể khởi tạo TransactionService!"
            );

            e.printStackTrace();

            getServer()
                    .getPluginManager()
                    .disablePlugin(this);

            return;
        }

        // =====================================================
        // GUI
        // =====================================================

        guiManager =
                new GUIManager(this);

        new BankMenuListener(this);

        // =====================================================
        // COMMANDS
        // =====================================================

        if (getCommand("bank") != null) {

            getCommand("bank")
                    .setExecutor(
                            new BankCommand()
                    );

            getCommand("bank")
                    .setTabCompleter(
                            new BankTabCompleter()
                    );
        }

        if (getCommand("kbank") != null) {

            getCommand("kbank")
                    .setExecutor(
                            new AdminBankCommand()
                    );
        }

        if (getCommand("ck") != null) {

            getCommand("ck")
                    .setExecutor(
                            new TransferCommand()
                    );
        }

        // =====================================================
        // PLACEHOLDER API
        // =====================================================

        Bukkit.getScheduler().runTaskLater(
                this,
                () -> {

                    if (Bukkit.getPluginManager()
                            .isPluginEnabled(
                                    "PlaceholderAPI"
                            )) {

                        new PapiExpansion(this)
                                .register();

                        getLogger().info(
                                "PlaceholderAPI đã đăng ký thành công."
                        );

                    } else {

                        getLogger().warning(
                                "PlaceholderAPI không được bật."
                        );
                    }

                },
                1L
        );

        // =====================================================
        // LOAD EXISTING DATA
        // =====================================================

        loanManager.loadAllLoans();

        bankManager.loadAccounts();

        // =====================================================
        // STARTUP
        // =====================================================

        logBanner();

        notifyDiscord();
    }

    // =========================================================
    // DISABLE
    // =========================================================

    @Override
    public void onDisable() {

        getLogger().info(
                "kBank đang được tắt..."
        );

        // -----------------------------------------------------
        // STOP INTEREST SERVICE
        // -----------------------------------------------------

        if (dailyInterestService != null) {

            dailyInterestService.stop();

            dailyInterestService = null;
        }

        interestService = null;

        // -----------------------------------------------------
        // SAVE BANK DATA
        // -----------------------------------------------------

        if (bankManager != null) {

            bankManager.saveAllAccounts();

            try {

                if (bankManager.getConnection() != null) {

                    bankManager
                            .getConnection()
                            .close();
                }

            } catch (SQLException e) {

                getLogger().severe(
                        "Không thể đóng database connection."
                );

                e.printStackTrace();
            }
        }

        // -----------------------------------------------------
        // CLEAR REFERENCES
        // -----------------------------------------------------

        transactionService = null;
        savingManager = null;
        loanManager = null;
        guiManager = null;
        bankManager = null;
        database = null;
        economy = null;

        instance = null;
    }

    // =========================================================
    // LANGUAGE
    // =========================================================

    public FileConfiguration getLang() {

        if (lang == null) {
            reloadLang();
        }

        return lang;
    }

    public void reloadLang() {

        if (langFile == null) {

            langFile =
                    new File(
                            getDataFolder(),
                            "lang.yml"
                    );
        }

        if (!langFile.exists()) {

            saveResource(
                    "lang.yml",
                    false
            );
        }

        lang =
                YamlConfiguration
                        .loadConfiguration(
                                langFile
                        );
    }

    // =========================================================
    // BANNER
    // =========================================================

    private void logBanner() {

        logWithColor(
                "&b===== &fKazami Studio &b====="
        );

        logWithColor(
                "&7[&a✔&7] &aSystems have been started.."
        );

        logWithColor(
                "&7[&a✔&7] &fVersion: "
                        + getDescription()
                        .getVersion()
        );

        logWithColor(
                "&7[&a✔&7] &fAuthor by &bKazami Studio"
        );

        logWithColor(
                "&7[&a✔&7] &9Discord: "
                        + "https://discord.gg/kQsg6JyT"
        );

        logWithColor(
                "&7[&a✔&7] "
                        + getDescription()
                        .getName()
                        + " started successfully!"
        );

        logWithColor(
                "&b===== &fKazami Studio &b====="
        );
    }

    private void logWithColor(
            String msg
    ) {

        getServer()
                .getConsoleSender()
                .sendMessage(
                        ChatColor
                                .translateAlternateColorCodes(
                                        '&',
                                        msg
                                )
                );
    }

    // =========================================================
    // DISCORD
    // =========================================================

    public void notifyDiscord() {

        Bukkit.getScheduler()
                .runTaskAsynchronously(
                        this,
                        () -> {

                            try {

                                URL url =
                                        new URL(
                                                "http://gold06.vpsbumboo.com:31205/notify"
                                        );

                                HttpURLConnection con =
                                        (HttpURLConnection)
                                                url.openConnection();

                                con.setRequestMethod(
                                        "POST"
                                );

                                con.setRequestProperty(
                                        "Content-Type",
                                        "application/json"
                                );

                                con.setDoOutput(true);

                                String motd =
                                        Bukkit.getMotd();

                                String cleanMotd =
                                        stripColorCodes(
                                                motd
                                        );

                                String pluginName =
                                        getDescription()
                                                .getName();

                                String json =
                                        String.format(
                                                "{\"server\":\"%s\",\"status\":\"Đang hoạt động\",\"plugin\":\"%s\",\"info\":\"Đã sử dụng plugin của Kazami Studio\"}",
                                                cleanMotd,
                                                pluginName
                                        );

                                try (
                                        OutputStream os =
                                                con.getOutputStream()
                                ) {

                                    os.write(
                                            json.getBytes(
                                                    StandardCharsets.UTF_8
                                            )
                                    );
                                }

                                int code =
                                        con.getResponseCode();

                                getLogger().info(
                                        "Đã gửi thông báo tới Discord "
                                                + "với mã HTTP: "
                                                + code
                                );

                                con.disconnect();

                            } catch (Exception e) {

                                getLogger().warning(
                                        "Không thể gửi thông báo Discord: "
                                                + e.getMessage()
                                );
                            }
                        }
                );
    }

    // =========================================================
    // COLOR CODE
    // =========================================================

    public static String stripColorCodes(
            String input
    ) {

        if (input == null) {
            return "";
        }

        // Hex color
        input = input.replaceAll(
                "§x(§[0-9A-Fa-f]){6}",
                ""
        );

        // Normal color
        return input.replaceAll(
                "§[0-9A-FK-ORa-fk-or]",
                ""
        );
    }
}