CRAFTOPIA BASIC ICONS - ITEMADDER
==================================

Đây là bản rút gọn từ pack trước.
Chỉ giữ 200 icon cơ bản, dùng bộ Classic 16x16.

Namespace: craftopia_icons
Folder: craftopia_icons

CÀI ĐẶT
-------
1. XÓA folder craftopia_icons cũ trong:
   plugins/ItemsAdder/contents/

2. Giải nén ZIP này và chép folder:
   craftopia_icons
   vào:
   plugins/ItemsAdder/contents/

3. Chạy:
   /iazip

4. Cho người chơi tải lại resource pack.

ID GIỮ NGUYÊN
-------------
Ví dụ:
  craftopia_icons:ck_icon_0201
  craftopia_icons:ck_icon_0591
  craftopia_icons:ck_icon_0721

Placeholder:
  :ck_icon_0201:

Skript:
  set {_icon} to fontimage "craftopia_icons:ck_icon_0201"
  send "%{_icon}% &fCraftopia Kingdom" to player

LƯU Ý
-----
- Namespace và ID của các icon được giữ giống pack full cũ.
- Các icon không nằm trong bản basic đã được loại bỏ.
- ItemsAdder tự cấp ký tự Unicode để tránh đụng icon hiện có.
- Xem PREVIEW_BASIC_ICONS.png và BASIC_ICON_CATALOG.csv để chọn icon.
